package com.fys.inventario.dao;

import com.fys.inventario.model.Herramienta;
import com.fys.inventario.model.Empleado; // Necesario para obtener el nombre completo del empleado
import com.fys.inventario.util.DatabaseConnection;
import com.fys.inventario.util.QrCodeUtil;
import com.fys.inventario.util.QrCodeUtil.QrType;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import com.google.zxing.WriterException;

/**
 * Clase DAO (Data Access Object) para la entidad Herramienta.
 * Provee métodos para interactuar con la tabla 'Herramientas' en la base de datos.
 */
public class HerramientaDAO {

    /**
     * Agrega una nueva herramienta a la base de datos.
     * El ID de la herramienta se generará automáticamente en la DB,
     * luego se genera y guarda el QR con ese ID.
     *
     * @param herramienta El objeto Herramienta a agregar.
     * @return true si la herramienta fue agregada exitosamente, false en caso contrario.
     */
    public boolean agregarHerramienta(Herramienta herramienta) {
        // La columna qr_code_path se actualizará después de obtener el ID
        String sql = "INSERT INTO Herramientas (nombre, marca, descripcion, estado, disponibilidad, asignado_a, qr_code_path) VALUES (?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            pstmt.setString(1, herramienta.getNombre());
            pstmt.setString(2, herramienta.getMarca());
            pstmt.setString(3, herramienta.getDescripcion());
            pstmt.setString(4, herramienta.getEstado());
            pstmt.setString(5, herramienta.getDisponibilidad());

            // Usar setObject para Integer, ya que puede ser null
            if (herramienta.getAsignadoAIdEmpleado() != null) {
                pstmt.setInt(6, herramienta.getAsignadoAIdEmpleado());
            } else {
                pstmt.setNull(6, java.sql.Types.INTEGER);
            }
            pstmt.setString(7, null); // qr_code_path inicialmente null

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    herramienta.setIdHerramienta(rs.getInt(1)); // Establecer el ID auto-generado

                    // --- GENERAR Y GUARDAR QR DESPUÉS DE OBTENER EL ID ---
                    String qrContent = String.valueOf(herramienta.getIdHerramienta()); // Contenido del QR es el ID de la herramienta
                    String qrFileName = "qr_herramienta_" + herramienta.getIdHerramienta();
                    String qrPath = null;
                    try {
                        qrPath = QrCodeUtil.generateAndSaveQrCode(qrContent, qrFileName, QrType.HERRAMIENTA);
                    } catch (IOException | WriterException e) {
                        System.err.println("Error al generar o guardar el código QR para la herramienta " + herramienta.getIdHerramienta() + ": " + e.getMessage());
                        e.printStackTrace();
                        // Continúa sin QR path si hay un error en la generación
                    }

                    if (qrPath != null) {
                        // Actualizar la herramienta en la DB con la ruta del QR
                        String updateSql = "UPDATE Herramientas SET qr_code_path = ? WHERE id_herramienta = ?";
                        try (PreparedStatement updatePstmt = conn.prepareStatement(updateSql)) {
                            updatePstmt.setString(1, qrPath);
                            updatePstmt.setInt(2, herramienta.getIdHerramienta());
                            updatePstmt.executeUpdate();
                            herramienta.setQrCodePath(qrPath); // Actualizar el objeto Herramienta también
                        }
                    }
                    // --- FIN GENERACIÓN Y ACTUALIZACIÓN QR ---
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error al agregar herramienta: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Obtiene una lista de todas las herramientas con el nombre completo del empleado asignado.
     * @return Una lista de objetos Herramienta.
     */
    public List<Herramienta> obtenerTodasHerramientas() {
        List<Herramienta> herramientas = new ArrayList<>();
        // CAMBIO AQUÍ: h.asignado_a en lugar de h.asignado_a_id_empleado
        String sql = "SELECT h.id_herramienta, h.nombre, h.marca, h.descripcion, h.estado, h.disponibilidad, h.asignado_a, h.qr_code_path, " +
                "e.nombres, e.apellidos " +
                "FROM Herramientas h LEFT JOIN Empleados e ON h.asignado_a = e.id_empleado";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                int idHerramienta = rs.getInt("id_herramienta");
                String nombre = rs.getString("nombre");
                String marca = rs.getString("marca");
                String descripcion = rs.getString("descripcion");
                String estado = rs.getString("estado");
                String disponibilidad = rs.getString("disponibilidad");
                // Leer asignado_a_id_empleado como Integer (puede ser null)
                Integer asignadoAIdEmpleado = null; // Inicializar a null
                if (rs.getObject("asignado_a") != null) {
                    asignadoAIdEmpleado = rs.getInt("asignado_a"); // Leer como int si no es null
                    // O si persiste el error, puedes probar:
                    // asignadoAIdEmpleado = ((Long) rs.getObject("asignado_a")).intValue();
                }
                String qrCodePath = rs.getString("qr_code_path");

                Herramienta herramienta = new Herramienta(idHerramienta, nombre, marca, descripcion, estado, disponibilidad, asignadoAIdEmpleado, qrCodePath);

                // Obtener y establecer el nombre completo del empleado asignado
                String nombreEmpleadoAsignado = rs.getString("nombres"); // Si ya haces un JOIN
                String apellidosEmpleadoAsignado = rs.getString("apellidos"); // Si ya haces un JOIN
                if (nombreEmpleadoAsignado != null && apellidosEmpleadoAsignado != null) {
                    herramienta.setAsignadoANombreCompleto(nombreEmpleadoAsignado + " " + apellidosEmpleadoAsignado);
                } else {
                    herramienta.setAsignadoANombreCompleto("N/A");
                }
                herramientas.add(herramienta);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener todas las herramientas: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return herramientas;
    }

    /**
     * Obtiene una herramienta por su ID.
     * @param idHerramienta El ID de la herramienta a buscar.
     * @return El objeto Herramienta si se encuentra, o null si no existe.
     */
    public Herramienta obtenerHerramientaPorId(int idHerramienta) {
        // CAMBIO AQUÍ: h.asignado_a en lugar de h.asignado_a_id_empleado
        String sql = "SELECT h.id_herramienta, h.nombre, h.marca, h.descripcion, h.estado, h.disponibilidad, h.asignado_a, h.qr_code_path, " +
                "e.nombres, e.apellidos " +
                "FROM Herramientas h LEFT JOIN Empleados e ON h.asignado_a = e.id_empleado WHERE h.id_herramienta = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Herramienta herramienta = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, idHerramienta);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                // Leer asignado_a_id_empleado como Integer
                Integer asignadoAIdEmpleado = (Integer) rs.getObject("asignado_a");
                Herramienta Herramienta = new Herramienta(
                        idHerramienta,
                        rs.getString("nombre"),
                        rs.getString("marca"),
                        rs.getString("descripcion"),
                        rs.getString("estado"),
                        rs.getString("disponibilidad"),
                        asignadoAIdEmpleado, // Pasa el Integer (o null)
                        rs.getString("qr_code_path")
                );
                String nombreEmpleadoAsignado = rs.getString("nombres"); // Si ya haces un JOIN
                String apellidosEmpleadoAsignado = rs.getString("apellidos"); // Si ya haces un JOIN
                if (nombreEmpleadoAsignado != null && apellidosEmpleadoAsignado != null) {
                    herramienta.setAsignadoANombreCompleto(nombreEmpleadoAsignado + " " + apellidosEmpleadoAsignado);
                } else {
                    herramienta.setAsignadoANombreCompleto("N/A");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener herramienta por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return herramienta;
    }

    /**
     * Actualiza la disponibilidad y, opcionalmente, la asignación de una herramienta a un empleado.
     *
     * @param idHerramienta El ID de la herramienta a actualizar.
     * @param disponibilidad El nuevo estado de disponibilidad (ej. "Libre", "En uso", "En mantenimiento").
     * @param idEmpleado El ID del empleado al que se asigna la herramienta. Puede ser null si la herramienta se libera.
     * @return true si la actualización fue exitosa, false en caso contrario.
     */
    public boolean actualizarDisponibilidad(int idHerramienta, String disponibilidad, Integer idEmpleado) { // CAMBIO AQUÍ: idEmpleado ahora es Integer
        String sql = "UPDATE Herramientas SET disponibilidad = ?, asignado_a = ? WHERE id_herramienta = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean exito = false;

        try {
            conn = DatabaseConnection.getConnection(); // Usar DatabaseConnection
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, disponibilidad);

            if (idEmpleado == null) {
                pstmt.setNull(2, Types.INTEGER); // Establecer como NULL si no hay empleado asignado
            } else {
                pstmt.setInt(2, idEmpleado); // Establecer el ID del empleado
            }
            pstmt.setInt(3, idHerramienta);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Disponibilidad de herramienta " + idHerramienta + " actualizada a '" + disponibilidad + "'.");
                exito = true;
            }
        } catch (SQLException e) {
            System.err.println("Error de SQL al actualizar disponibilidad de herramienta: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (pstmt != null) pstmt.close();
                // No cerrar la conexión aquí si la estás gestionando externamente (ej. pool de conexiones)
                // if (conn != null) conn.close(); // Cierra la conexión si no usas pool
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos en actualizarDisponibilidad: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return exito;
    }


    /**
     * Actualiza la información de una herramienta existente en la base de datos.
     * @param herramienta El objeto Herramienta con la información actualizada.
     * @return true si la herramienta fue actualizada exitosamente, false en caso contrario.
     */
    public boolean actualizarHerramienta(Herramienta herramienta) {
        String sql = "UPDATE Herramientas SET nombre = ?, marca = ?, descripcion = ?, estado = ?, disponibilidad = ?, asignado_a = ?, qr_code_path = ? WHERE id_herramienta = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);

            // --- Lógica de Re-Generación de QR para Herramienta ---
            // Solo generar/re-generar si qrCodePath es null o vacío.
            if (herramienta.getQrCodePath() == null || herramienta.getQrCodePath().isEmpty()) {
                String qrContent = String.valueOf(herramienta.getIdHerramienta());
                String qrFileName = "qr_herramienta_" + herramienta.getIdHerramienta();
                String qrPath = null;
                try {
                    qrPath = QrCodeUtil.generateAndSaveQrCode(qrContent, qrFileName, QrType.HERRAMIENTA);
                } catch (IOException | WriterException e) {
                    System.err.println("Error al generar/re-generar el código QR para la herramienta " + herramienta.getIdHerramienta() + ": " + e.getMessage());
                    e.printStackTrace();
                    // No retornamos false aquí, permitimos la actualización del resto de campos.
                }
                if (qrPath != null) {
                    herramienta.setQrCodePath(qrPath); // Actualizar el objeto con la nueva ruta QR
                }
            }
            // FIN Lógica de Re-Generación de QR para Herramienta

            pstmt.setString(1, herramienta.getNombre());
            pstmt.setString(2, herramienta.getMarca());
            pstmt.setString(3, herramienta.getDescripcion());
            pstmt.setString(4, herramienta.getEstado());
            pstmt.setString(5, herramienta.getDisponibilidad());
            // Usar setObject o setInt para Integer, para manejar nulls
            if (herramienta.getAsignadoAIdEmpleado() != null) {
                pstmt.setInt(6, herramienta.getAsignadoAIdEmpleado());
            } else {
                pstmt.setNull(6, java.sql.Types.INTEGER);
            }
            pstmt.setString(7, herramienta.getQrCodePath());
            pstmt.setInt(8, herramienta.getIdHerramienta());

            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar herramienta: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
    }

    /**
     * Busca herramientas por un fragmento de su nombre o descripción.
     *
     * @param nombre O descripción a buscar.
     * @return Una lista de Herramienta que coinciden con la búsqueda, o una lista vacía si no se encuentran.
     */
    public List<Herramienta> buscarHerramientasPorNombre(String nombre) {
        List<Herramienta> herramientas = new ArrayList<>();
        // Unir con Empleados para obtener el nombre del empleado asignado
        String sql = "SELECT h.id_herramienta, h.nombre, h.marca, h.descripcion, h.estado, h.disponibilidad, h.qr_code_path, " +
                "h.asignado_a, e.nombres, e.apellidos " +
                "FROM Herramientas h LEFT JOIN Empleados e ON h.asignado_a = e.id_empleado " +
                "WHERE h.nombre LIKE ? OR h.descripcion LIKE ?"; // Buscar en nombre o descripción
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "%" + nombre + "%"); // Para búsqueda parcial
            pstmt.setString(2, "%" + nombre + "%"); // Para búsqueda parcial

            rs = pstmt.executeQuery();

            while (rs.next()) {
                Herramienta herramienta = new Herramienta();
                herramienta.setIdHerramienta(rs.getInt("id_herramienta"));
                herramienta.setNombre(rs.getString("nombre"));
                herramienta.setMarca(rs.getString("marca"));
                herramienta.setDescripcion(rs.getString("descripcion"));
                herramienta.setEstado(rs.getString("estado"));
                herramienta.setDisponibilidad(rs.getString("disponibilidad"));
                herramienta.setQrCodePath(rs.getString("qr_code_path"));

                // Si hay un empleado asignado
                Integer asignadoAIdEmpleado = rs.getObject("asignado_a", Integer.class); // Usar getObject con Integer.class
                herramienta.setAsignadoAIdEmpleado(asignadoAIdEmpleado);

                if (asignadoAIdEmpleado != null) {
                    // Solo establece el nombre completo si hay un empleado asignado
                    herramienta.setAsignadoANombreCompleto(rs.getString("nombres") + " " + rs.getString("apellidos"));
                } else {
                    herramienta.setAsignadoANombreCompleto(null); // O cadena vacía, según tu preferencia
                }

                herramientas.add(herramienta);
            }
        } catch (SQLException e) {
            System.err.println("Error de SQL al buscar herramientas por nombre: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                // No cerrar la conexión aquí si la estás gestionando externamente (ej. pool de conexiones)
                // if (conn != null) conn.close(); // Cierra la conexión si no usas pool
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos en buscarHerramientasPorNombre: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return herramientas;
    }
    /**
     * Elimina una herramienta de la base de datos.
     * @param idHerramienta El ID de la herramienta a eliminar.
     * @return true si la herramienta fue eliminada exitosamente, false en caso contrario.
     */
    public boolean eliminarHerramienta(int idHerramienta) {
        String sql = "DELETE FROM Herramientas WHERE id_herramienta = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, idHerramienta);

            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar herramienta: " + e.getMessage());
            e.printStackTrace(); // Imprimir el stack trace para depuración
            return false;
        } finally {
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
    }
}