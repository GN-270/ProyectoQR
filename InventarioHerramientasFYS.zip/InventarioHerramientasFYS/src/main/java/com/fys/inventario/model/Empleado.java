package com.fys.inventario.model;

public class Empleado {
    private int idEmpleado;
    private String dni;
    private String nombres;
    private String apellidos;
    private String labor;
    private String qrCodePath; // Ruta del archivo del código QR


    public Empleado(int idEmpleado, String dni, String nombres, String apellidos, String labor, String qrCodePath) {
        this.idEmpleado = idEmpleado;
        this.dni = dni;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.labor = labor;
        this.qrCodePath = qrCodePath;
    }


    public Empleado(String dni, String nombres, String apellidos, String labor) {
        this.dni = dni;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.labor = labor;
        this.qrCodePath = null;
    }


    public Empleado(String dni, String nombres, String apellidos, String labor, String qrCodePath) {
        this.dni = dni;
        this.nombres = nombres;
        this.apellidos = apellidos;
        this.labor = labor;
        this.qrCodePath = qrCodePath;
    }


    public Empleado() {
    }


    public int getIdEmpleado() { // Retorna int
        return idEmpleado;
    }

    public void setIdEmpleado(int idEmpleado) { // Recibe int
        this.idEmpleado = idEmpleado;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getLabor() {
        return labor;
    }

    public void setLabor(String labor) {
        this.labor = labor;
    }

    public String getQrCodePath() {
        return qrCodePath;
    }

    public void setQrCodePath(String qrCodePath) {
        this.qrCodePath = qrCodePath;
    }

    @Override
    public String toString() {
        return "Empleado{" +
                "idEmpleado=" + idEmpleado +
                ", dni='" + dni + '\'' +
                ", nombres='" + nombres + '\'' +
                ", apellidos='" + apellidos + '\'' +
                ", labor='" + labor + '\'' +
                ", qrCodePath='" + qrCodePath + '\'' +
                '}';
    }
}