package com.fys.inventario.ui;

import com.fys.inventario.model.Empleado; // Todavía necesitamos Empleado

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginDialog extends JDialog {

    private JTextField txtUsuario; // Cambiado a txtUsuario para mayor claridad
    private JPasswordField txtPassword;
    private JButton btnLogin;

    public enum LoginResult {
        ADMIN_SUCCESS,
        FAILURE,
        CANCELLED
    }

    private LoginResult loginResult = LoginResult.CANCELLED;
    // loggedInAdmin no contendrá 'tipoUsuario' directamente con tus constructores actuales,
    // pero MainApp ya sabrá que fue un ADMIN_SUCCESS por el enum.
    private Empleado loggedInAdminData; // Usaremos un nombre diferente para evitar confusiones con "admin logueado" completo

    public LoginDialog(JFrame parent) {
        super(parent, "Iniciar Sesión de Administrador", true);
        setSize(400, 250);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        initComponents();
        setupListeners();
    }

    private void initComponents() {
        setLayout(new BorderLayout(15, 15));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel formPanel = new JPanel(new GridLayout(2, 2, 10, 10));
        formPanel.add(new JLabel("Usuario:"));
        txtUsuario = new JTextField();
        formPanel.add(txtUsuario);

        formPanel.add(new JLabel("Contraseña:"));
        txtPassword = new JPasswordField();
        formPanel.add(txtPassword);

        add(formPanel, BorderLayout.CENTER);

        btnLogin = new JButton("Iniciar Sesión");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 14));
        add(btnLogin, BorderLayout.SOUTH);
    }

    private void setupListeners() {
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usuario = txtUsuario.getText();
                String password = new String(txtPassword.getPassword());

                // --- AUTENTICACIÓN HARDCODEADA ---
                final String ADMIN_USER = "admin";
                final String ADMIN_PASS = "admin123";

                if (usuario.equals(ADMIN_USER) && password.equals(ADMIN_PASS)) {
                    // Si las credenciales son correctas, crea un objeto Empleado con la información básica
                    // utilizando uno de tus constructores existentes.
                    // MainApp sabrá que es un administrador por el LoginResult, no por este objeto Empleado en sí.
                    loggedInAdminData = new Empleado(
                            "adminDNI", // DNI ficticio para cumplir con el constructor
                            "Administrador",
                            "Principal",
                            "Gestion"
                            // El constructor (String dni, String nombres, String apellidos, String labor)
                            // no tiene qrCodePath, por lo que será null, lo cual está bien para un admin hardcodeado.
                    );

                    loginResult = LoginResult.ADMIN_SUCCESS;
                    JOptionPane.showMessageDialog(LoginDialog.this, "¡Bienvenido, Administrador!", "Inicio de Sesión Exitoso", JOptionPane.INFORMATION_MESSAGE);
                    dispose(); // Cierra el diálogo de login
                } else {
                    JOptionPane.showMessageDialog(LoginDialog.this, "Credenciales de administrador incorrectas. Intente de nuevo.", "Error de Inicio de Sesión", JOptionPane.ERROR_MESSAGE);
                    loginResult = LoginResult.FAILURE;
                }
            }
        });
    }

    public LoginResult getLoginResult() {
        return loginResult;
    }

    // Este getter devolverá el objeto Empleado "falso" para el administrador.
    // MainApp lo usará para el AdminDashboardFrame, pero no llamará a getTipoUsuario() en él.
    public Empleado getLoggedInAdmin() {
        return loggedInAdminData;
    }
}