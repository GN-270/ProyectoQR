package com.fys.inventario.ui;

import com.fys.inventario.dao.HistorialMovimientoDAO;
import com.fys.inventario.dao.EmpleadoDAO;
import com.fys.inventario.dao.HerramientaDAO;
import com.fys.inventario.model.HistorialMovimiento;
import com.fys.inventario.model.Empleado;
import com.fys.inventario.model.Herramienta;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Vector;
import java.util.stream.Collectors;

public class HistorialMovimientosDialog extends JDialog {

    private HistorialMovimientoDAO historialDAO;
    private EmpleadoDAO empleadoDAO;
    private HerramientaDAO herramientaDAO;

    private DefaultTableModel tableModel;
    private JTable historialTable;

    // Componentes de filtrado
    private JComboBox<EmpleadoComboBoxItem> cmbFiltrarEmpleado;
    private JComboBox<HerramientaComboBoxItem> cmbFiltrarHerramienta;
    private JComboBox<String> cmbFiltrarTipo;
    private JButton btnFiltrar;
    private JButton btnLimpiarFiltros;

    private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");


    public HistorialMovimientosDialog(JFrame parent) {
        super(parent, "Historial de Movimientos", true);
        historialDAO = new HistorialMovimientoDAO();
        empleadoDAO = new EmpleadoDAO();
        herramientaDAO = new HerramientaDAO();

        setSize(1000, 700);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        initComponents();
        loadInitialData();
        populateFilterComboBoxes();
    }

    private void initComponents() {
        JPanel filterPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        filterPanel.setBorder(BorderFactory.createTitledBorder("Filtros de Búsqueda"));

        filterPanel.add(new JLabel("Empleado:"));
        cmbFiltrarEmpleado = new JComboBox<>();
        filterPanel.add(cmbFiltrarEmpleado);

        filterPanel.add(new JLabel("Herramienta:"));
        cmbFiltrarHerramienta = new JComboBox<>();
        filterPanel.add(cmbFiltrarHerramienta);

        filterPanel.add(new JLabel("Tipo:"));
        // Asegúrate que estos tipos coincidan exactamente con los valores en tu DB (Ej: "Prestacion", "Devolucion")
        String[] tiposMovimiento = {"Todos", "Prestacion", "Devolucion"}; // Confirma que "Prestacion" y "Devolucion" son EXACTOS como en tu DB ENUM
        cmbFiltrarTipo = new JComboBox<>(tiposMovimiento);
        filterPanel.add(cmbFiltrarTipo);

        btnFiltrar = new JButton("Aplicar Filtros");
        btnLimpiarFiltros = new JButton("Limpiar Filtros");

        filterPanel.add(btnFiltrar);
        filterPanel.add(btnLimpiarFiltros);

        add(filterPanel, BorderLayout.NORTH);

        String[] columnNames = {"ID Movimiento", "ID Herramienta", "Nombre Herramienta", "ID Empleado", "Nombre Empleado", "Tipo de Acción", "Fecha/Hora", "Comentarios"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        historialTable = new JTable(tableModel);
        historialTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(historialTable);
        add(scrollPane, BorderLayout.CENTER);

        btnFiltrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                applyFilters();
            }
        });

        btnLimpiarFiltros.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarFiltros();
            }
        });
    }

    private void populateFilterComboBoxes() {
        cmbFiltrarEmpleado.removeAllItems();
        // El ID null en EmpleadoComboBoxItem significa "Todos los Empleados"
        cmbFiltrarEmpleado.addItem(new EmpleadoComboBoxItem(null, "Todos los Empleados"));
        List<Empleado> empleados = empleadoDAO.obtenerTodosEmpleados();
        for (Empleado emp : empleados) {
            // emp.getIdEmpleado() devuelve int, que se autoboxea a Integer para el constructor
            cmbFiltrarEmpleado.addItem(new EmpleadoComboBoxItem(emp.getIdEmpleado(), emp.getNombres() + " " + emp.getApellidos()));
        }

        cmbFiltrarHerramienta.removeAllItems();
        // El ID 0 para HerramientaComboBoxItem significa "Todas las Herramientas"
        cmbFiltrarHerramienta.addItem(new HerramientaComboBoxItem(0, "Todas las Herramientas"));
        List<Herramienta> herramientas = herramientaDAO.obtenerTodasHerramientas();
        for (Herramienta h : herramientas) {
            cmbFiltrarHerramienta.addItem(new HerramientaComboBoxItem(h.getIdHerramienta(), h.getNombre() + " (" + h.getMarca() + ")"));
        }
    }

    private void loadInitialData() {
        loadHistorial(historialDAO.obtenerTodosMovimientos());
    }

    private void loadHistorial(List<HistorialMovimiento> movimientos) {
        tableModel.setRowCount(0);
        for (HistorialMovimiento mov : movimientos) {
            tableModel.addRow(new Object[]{
                    mov.getIdMovimiento(),
                    mov.getIdHerramienta(),
                    mov.getNombreHerramienta(),
                    mov.getIdEmpleado() != null ? String.valueOf(mov.getIdEmpleado()) : "",
                    mov.getNombreEmpleado(),
                    mov.getTipoAccion(), // <--- CAMBIO AQUÍ: de getTipoMovimiento() a getTipoAccion()
                    mov.getFechaHora().format(DATETIME_FORMATTER),
                    mov.getComentarios() // <--- CAMBIO AQUÍ: de getObservaciones() a getComentarios()
            });
        }
    }

    private void applyFilters() {
        Integer selectedEmpleadoId = null; // Cambiado a Integer para permitir null
        if (cmbFiltrarEmpleado.getSelectedItem() instanceof EmpleadoComboBoxItem) {
            EmpleadoComboBoxItem selectedItem = (EmpleadoComboBoxItem) cmbFiltrarEmpleado.getSelectedItem();
            selectedEmpleadoId = selectedItem.getIdEmpleado(); // Esto será null si es "Todos los Empleados"
        }

        Integer selectedHerramientaId = null; // Ya era Integer, se mantiene
        if (cmbFiltrarHerramienta.getSelectedItem() instanceof HerramientaComboBoxItem) {
            HerramientaComboBoxItem selectedItem = (HerramientaComboBoxItem) cmbFiltrarHerramienta.getSelectedItem();
            if (selectedItem.getIdHerramienta() != 0) { // El ID 0 es para "Todas las Herramientas"
                selectedHerramientaId = selectedItem.getIdHerramienta();
            }
        }

        String selectedTipo = (String) cmbFiltrarTipo.getSelectedItem();
        // Si el tipo es "Todos" o nulo/vacío, pasamos null al DAO para que no filtre por tipo
        String tipoFiltrar = "Todos".equalsIgnoreCase(selectedTipo) || selectedTipo == null || selectedTipo.isEmpty() ? null : selectedTipo;

        List<HistorialMovimiento> movimientosFiltrados = historialDAO.buscarMovimientos(
                selectedEmpleadoId, selectedHerramientaId, tipoFiltrar
        );
        loadHistorial(movimientosFiltrados);
    }

    private void limpiarFiltros() {
        cmbFiltrarEmpleado.setSelectedIndex(0);
        cmbFiltrarHerramienta.setSelectedIndex(0);
        cmbFiltrarTipo.setSelectedIndex(0);
        loadInitialData();
    }

    // Clases internas para los items de los ComboBox (Empleado y Herramienta)
    private static class EmpleadoComboBoxItem {
        private Integer idEmpleado; // Cambiado a Integer
        private String displayName;

        public EmpleadoComboBoxItem(Integer idEmpleado, String displayName) { // Constructor acepta Integer
            this.idEmpleado = idEmpleado;
            this.displayName = displayName;
        }

        public Integer getIdEmpleado() { // Retorna Integer
            return idEmpleado;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }

    private static class HerramientaComboBoxItem {
        private int idHerramienta;
        private String displayName;

        public HerramientaComboBoxItem(int idHerramienta, String displayName) {
            this.idHerramienta = idHerramienta;
            this.displayName = displayName;
        }

        public int getIdHerramienta() {
            return idHerramienta;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }
}