package com.fys.inventario.ui;

import com.fys.inventario.dao.HerramientaDAO;
import com.fys.inventario.dao.HistorialMovimientoDAO;
import com.fys.inventario.model.Herramienta;
import com.fys.inventario.model.Empleado;
import com.fys.inventario.model.HistorialMovimiento;

import javax.swing.*;
import java.awt.*;
import java.time.LocalDateTime; // Usar LocalDateTime en lugar de java.util.Date

public class ToolReturnDetailsDialog extends JDialog {

    private int toolId;
    private Empleado returningEmployee;
    private HerramientaDAO herramientaDAO;
    private HistorialMovimientoDAO historialDAO;
    private Herramienta toolToReturn;

    private JTextArea txtComments;
    private JComboBox<String> cmbCondition;
    private JButton btnConfirmReturn;

    private boolean returnSuccessful = false;

    public ToolReturnDetailsDialog(JDialog parent, int toolId, Empleado returningEmployee) {
        super(parent, "Detalles de Devolución de Herramienta", true);
        this.toolId = toolId;
        this.returningEmployee = returningEmployee;
        this.herramientaDAO = new HerramientaDAO();
        this.historialDAO = new HistorialMovimientoDAO();

        setSize(450, 350);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        toolToReturn = herramientaDAO.obtenerHerramientaPorId(toolId);
        if (toolToReturn == null) {
            JOptionPane.showMessageDialog(this, "La herramienta con ID " + toolId + " no existe.", "Error", JOptionPane.ERROR_MESSAGE);
            dispose();
            return;
        }

        // Verificar si la herramienta está actualmente asignada a este empleado (opcional pero recomendado)
        // Usar getAsignadoAIdEmpleado() para obtener el ID
        if (toolToReturn.getAsignadoAIdEmpleado() == null || !toolToReturn.getAsignadoAIdEmpleado().equals(returningEmployee.getIdEmpleado())) {
            JOptionPane.showMessageDialog(this, "La herramienta no está registrada como prestada a este usuario, o no está prestada. Continúe bajo su responsabilidad.", "Advertencia", JOptionPane.WARNING_MESSAGE);
        }

        initComponents();
        setupListeners();
        displayToolInfo();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Asegurarse de que el nombre del empleado asignado se muestre correctamente si existe
        String asignadoAInfo = toolToReturn.getAsignadoANombreCompleto() != null ?
                toolToReturn.getAsignadoANombreCompleto() : "N/A";

        JLabel toolInfoLabel = new JLabel("<html><b>Herramienta:</b> " + toolToReturn.getNombre() + " (ID: " + toolToReturn.getIdHerramienta() + ")<br>" +
                "<b>Marca:</b> " + toolToReturn.getMarca() + "<br>" +
                "<b>Estado actual:</b> " + toolToReturn.getEstado() + "<br>" +
                "<b>Disponibilidad:</b> " + toolToReturn.getDisponibilidad() + "<br>" +
                "<b>Asignado a:</b> " + asignadoAInfo + "</html>"); // Añadir quién la tiene asignada
        toolInfoLabel.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        mainPanel.add(toolInfoLabel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new GridLayout(2, 1, 10, 10));

        // Campo de comentarios
        JPanel commentPanel = new JPanel(new BorderLayout());
        commentPanel.add(new JLabel("Comentarios sobre la devolución (daños, etc.):"), BorderLayout.NORTH);
        txtComments = new JTextArea(4, 20);
        txtComments.setLineWrap(true);
        txtComments.setWrapStyleWord(true);
        JScrollPane scrollComments = new JScrollPane(txtComments);
        commentPanel.add(scrollComments, BorderLayout.CENTER);
        inputPanel.add(commentPanel);

        // Selector de estado
        JPanel conditionPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        conditionPanel.add(new JLabel("Nuevo estado de la herramienta:"));
        cmbCondition = new JComboBox<>(new String[]{"Excelente", "Regular", "Pésimo"});
        cmbCondition.setSelectedItem(toolToReturn.getEstado());
        conditionPanel.add(cmbCondition);
        inputPanel.add(conditionPanel);

        mainPanel.add(inputPanel, BorderLayout.CENTER);

        btnConfirmReturn = new JButton("Confirmar Devolución");
        btnConfirmReturn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        mainPanel.add(btnConfirmReturn, BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        btnConfirmReturn.addActionListener(e -> {
            String comments = txtComments.getText().trim();
            String newCondition = (String) cmbCondition.getSelectedItem();

            // 1. Actualizar la herramienta en la base de datos (disponibilidad y estado, desasignar)
            toolToReturn.setEstado(newCondition);
            toolToReturn.setDisponibilidad("Libre"); // La herramienta vuelve a estar libre
            toolToReturn.setAsignadoAIdEmpleado(null); // Corregido: Usar setAsignadoAIdEmpleado() y establecer a null

            boolean updateSuccess = herramientaDAO.actualizarHerramienta(toolToReturn);

            // 2. Registrar la devolución en el historial
            boolean historySuccess = false;
            if (updateSuccess) {
                // Constructor para un nuevo movimiento:
                // HistorialMovimiento(Integer idHerramienta, Integer idEmpleado, String tipoAccion, LocalDateTime fechaHora, String comentarios)
                HistorialMovimiento historial = new HistorialMovimiento(
                        toolToReturn.getIdHerramienta(),
                        returningEmployee.getIdEmpleado(), // El empleado que está devolviendo
                        "Devolución",
                        LocalDateTime.now(), // Usar LocalDateTime.now()
                        "Herramienta devuelta. Nuevo estado: " + newCondition + ". Comentarios: " + (comments.isEmpty() ? "Ninguno." : comments)
                );
                historySuccess = historialDAO.agregarMovimiento(historial);
            }

            if (updateSuccess && historySuccess) {
                JOptionPane.showMessageDialog(this, "Herramienta devuelta exitosamente.", "Devolución Exitosa", JOptionPane.INFORMATION_MESSAGE);
                returnSuccessful = true;
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "Hubo un error al procesar la devolución. Intente de nuevo.", "Error de Devolución", JOptionPane.ERROR_MESSAGE);
                returnSuccessful = false;
            }
        });
    }

    private void displayToolInfo() {
        // La información ya se carga en el constructor y se muestra en initComponents
    }

    public boolean isReturnSuccessful() {
        return returnSuccessful;
    }
}