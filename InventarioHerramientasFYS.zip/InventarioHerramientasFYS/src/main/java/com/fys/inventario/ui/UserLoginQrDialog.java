package com.fys.inventario.ui;

import com.fys.inventario.dao.EmpleadoDAO;
import com.fys.inventario.model.Empleado;
import com.fys.inventario.util.QrCodeUtil; // Asume que tienes QrCodeUtil

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import com.google.zxing.NotFoundException; // Para manejar errores de lectura de QR
import com.google.zxing.WriterException; // Aunque no se usa directamente aquí, puede ser útil

public class UserLoginQrDialog extends JDialog {

    private EmpleadoDAO empleadoDAO;
    private JLabel lblQrStatus;
    private JButton btnScanQr;

    public enum LoginResult {
        SUCCESS,
        FAILURE,
        CANCELLED
    }

    private LoginResult result = LoginResult.CANCELLED;
    private Empleado loggedInEmployee = null;

    public UserLoginQrDialog(JFrame parent) {
        super(parent, "Iniciar Sesión de Usuario (Escaneo QR)", true);
        empleadoDAO = new EmpleadoDAO();
        setSize(400, 250);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        initComponents();
        setupListeners();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        lblQrStatus = new JLabel("Escanee el código QR de su credencial de empleado.", SwingConstants.CENTER);
        lblQrStatus.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        panel.add(lblQrStatus, gbc);

        btnScanQr = new JButton("Escanear QR (Seleccionar Archivo)");
        btnScanQr.setFont(new Font("Segoe UI", Font.BOLD, 14));
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        panel.add(btnScanQr, gbc);

        add(panel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        btnScanQr.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Simulación de escaneo QR: Abrir un JFileChooser para seleccionar una imagen
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setDialogTitle("Seleccione la imagen del código QR de su credencial");
                int userSelection = fileChooser.showOpenDialog(UserLoginQrDialog.this);

                if (userSelection == JFileChooser.APPROVE_OPTION) {
                    File qrImageFile = fileChooser.getSelectedFile();
                    try {
                        String qrContent = QrCodeUtil.readQrCode(qrImageFile);
                        // Suponemos que el contenido del QR es el ID del empleado (un número)
                        int employeeId = Integer.parseInt(qrContent.trim());

                        // Buscar el empleado en la base de datos
                        Empleado employee = empleadoDAO.obtenerEmpleadoPorId(employeeId);

                        if (employee != null) {
                            loggedInEmployee = employee;
                            result = LoginResult.SUCCESS;
                            JOptionPane.showMessageDialog(UserLoginQrDialog.this,
                                    "Bienvenido, " + employee.getNombres() + " " + employee.getApellidos() + "!",
                                    "Login Exitoso", JOptionPane.INFORMATION_MESSAGE);
                            dispose(); // Cierra el diálogo de login QR
                        } else {
                            lblQrStatus.setText("QR no válido: Empleado no encontrado. Intente de nuevo.");
                            JOptionPane.showMessageDialog(UserLoginQrDialog.this,
                                    "El código QR no corresponde a un empleado válido.",
                                    "Error de QR", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (NumberFormatException ex) {
                        lblQrStatus.setText("QR no válido: Contenido inválido. Intente de nuevo.");
                        JOptionPane.showMessageDialog(UserLoginQrDialog.this,
                                "El contenido del QR no es un ID de empleado válido.",
                                "Error de QR", JOptionPane.ERROR_MESSAGE);
                        ex.printStackTrace();
                    } catch (IOException | NotFoundException ex) { // NotFoundException de ZXing
                        lblQrStatus.setText("Error al leer el QR. Asegúrese de que sea una imagen de QR válida.");
                        JOptionPane.showMessageDialog(UserLoginQrDialog.this,
                                "No se pudo leer el código QR de la imagen seleccionada. Error: " + ex.getMessage(),
                                "Error de Lectura QR", JOptionPane.ERROR_MESSAGE);
                        ex.printStackTrace();
                    }
                } else {
                    lblQrStatus.setText("Escaneo QR cancelado.");
                    // Si el usuario cancela, el resultado sigue siendo CANCELLED por defecto
                }
            }
        });
    }

    public LoginResult getLoginResult() {
        return result;
    }

    public Empleado getLoggedInEmployee() {
        return loggedInEmployee;
    }
}