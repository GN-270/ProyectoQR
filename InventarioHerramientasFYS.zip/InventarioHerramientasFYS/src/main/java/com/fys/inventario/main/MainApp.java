package com.fys.inventario.main;

import com.fys.inventario.ui.EmpleadoManagementDialog;
import com.fys.inventario.ui.HerramientaManagementDialog;
import com.fys.inventario.ui.HistorialMovimientosDialog; // <--- ASEGÚRATE DE QUE ESTA LÍNEA EXISTA

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.awt.Dimension;
import java.awt.Component;

public class MainApp extends JFrame {

    private JButton btnGestionEmpleados;
    private JButton btnGestionHerramientas;
    private JButton btnHistorialMovimientos;
    private JButton btnSalir;

    public MainApp() {
        setTitle("Sistema de Gestión de Inventario F&S");
        setSize(500, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(30, 30, 30, 30));

        JLabel welcomeLabel = new JLabel("Bienvenido al Sistema de Inventario F&S");
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        welcomeLabel.setAlignmentX(CENTER_ALIGNMENT);
        mainPanel.add(welcomeLabel);
        mainPanel.add(Box.createVerticalStrut(30));

        btnGestionEmpleados = new JButton("Gestión de Empleados");
        btnGestionHerramientas = new JButton("Gestión de Herramientas");
        btnHistorialMovimientos = new JButton("Historial de Movimientos");
        btnSalir = new JButton("Salir");

        Dimension buttonSize = new Dimension(250, 40);
        Font buttonFont = new Font("Segoe UI", Font.PLAIN, 16);

        setupButton(btnGestionEmpleados, buttonSize, buttonFont);
        setupButton(btnGestionHerramientas, buttonSize, buttonFont);
        setupButton(btnHistorialMovimientos, buttonSize, buttonFont);
        setupButton(btnSalir, buttonSize, buttonFont);

        mainPanel.add(btnGestionEmpleados);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(btnGestionHerramientas);
        mainPanel.add(Box.createVerticalStrut(15));
        mainPanel.add(btnHistorialMovimientos);
        mainPanel.add(Box.createVerticalStrut(30));
        mainPanel.add(btnSalir);

        add(mainPanel);

        btnGestionEmpleados.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EmpleadoManagementDialog empleadoDialog = new EmpleadoManagementDialog(MainApp.this);
                empleadoDialog.setVisible(true);
            }
        });

        btnGestionHerramientas.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                HerramientaManagementDialog herramientaDialog = new HerramientaManagementDialog(MainApp.this);
                herramientaDialog.setVisible(true);
            }
        });

        // --- Evento del botón de Historial de Movimientos (MODIFICADO) ---
        btnHistorialMovimientos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                HistorialMovimientosDialog historialDialog = new HistorialMovimientosDialog(MainApp.this);
                historialDialog.setVisible(true);
            }
        });

        btnSalir.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int confirm = JOptionPane.showConfirmDialog(MainApp.this,
                        "¿Estás seguro de que quieres salir?", "Confirmar Salida",
                        JOptionPane.YES_NO_OPTION);
                if (confirm == JOptionPane.YES_OPTION) {
                    System.exit(0);
                }
            }
        });

    }

    private void setupButton(JButton button, Dimension size, Font font) {
        button.setMaximumSize(size);
        button.setMinimumSize(size);
        button.setPreferredSize(size);
        button.setAlignmentX(CENTER_ALIGNMENT);
        button.setFont(font);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new MainApp().setVisible(true);
            }
        });
    }
}