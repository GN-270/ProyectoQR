package com.fys.inventario.ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import com.fys.inventario.main.MainApp;
import com.fys.inventario.model.Empleado;

public class UserDashboardDialog extends JDialog {

    private JLabel lblWelcome;
    private JButton btnViewTools;
    private JButton btnViewEmployees;
    private JButton btnReturnTool;
    private JButton btnLogout;

    private Empleado loggedInEmployee;

    public UserDashboardDialog(JFrame parent, Empleado employee) {
        super(parent, "Panel de Usuario", true);
        this.loggedInEmployee = employee;
        setSize(600, 400);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        initComponents();
        setupListeners();

        lblWelcome.setText("Bienvenido, " + loggedInEmployee.getNombres() + " " + loggedInEmployee.getApellidos() + "!");
        btnViewTools.setEnabled(true);
        btnViewEmployees.setEnabled(true);
        btnReturnTool.setEnabled(true);
        btnLogout.setEnabled(true);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        lblWelcome = new JLabel("Cargando...", SwingConstants.CENTER);
        lblWelcome.setFont(new Font("Segoe UI", Font.BOLD, 20));
        add(lblWelcome, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel(new GridLayout(4, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        btnViewTools = new JButton("Ver Inventario de Herramientas");
        btnViewTools.setFont(new Font("Segoe UI", Font.PLAIN, 16));

        btnViewEmployees = new JButton("Ver Empleados");
        btnViewEmployees.setFont(new Font("Segoe UI", Font.PLAIN, 16));

        btnReturnTool = new JButton("Devolver Herramienta");
        btnReturnTool.setFont(new Font("Segoe UI", Font.PLAIN, 16));

        btnLogout = new JButton("Cerrar Sesión");
        btnLogout.setFont(new Font("Segoe UI", Font.PLAIN, 16));

        buttonPanel.add(btnViewTools);
        buttonPanel.add(btnViewEmployees);
        buttonPanel.add(btnReturnTool);
        buttonPanel.add(btnLogout);

        add(buttonPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        btnViewTools.addActionListener(e -> {
            if (loggedInEmployee != null) {
                UserToolBrowserDialog toolBrowser = new UserToolBrowserDialog(this, loggedInEmployee);
                toolBrowser.setVisible(true);
            } else {
                JOptionPane.showMessageDialog(this, "Primero debe iniciar sesión como empleado para ver el inventario.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        btnViewEmployees.addActionListener(e -> {
            EmployeeViewerDialog employeeViewer = new EmployeeViewerDialog(this);
            employeeViewer.setVisible(true);
        });

        // --- MODIFICACIÓN CORREGIDA para "Devolver Herramienta" ---
        btnReturnTool.addActionListener(e -> {
            if (loggedInEmployee == null) {
                JOptionPane.showMessageDialog(this, "Debe iniciar sesión para devolver una herramienta.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // El ToolReturnQrScanDialog ahora maneja todo el flujo de escaneo y devolución de detalles
            // Se le pasa el 'parent' (este diálogo) y el empleado logeado.
            ToolReturnQrScanDialog qrScanDialog = new ToolReturnQrScanDialog(this, loggedInEmployee);
            qrScanDialog.setVisible(true); // Este diálogo se bloqueará hasta que qrScanDialog se cierre

            // No necesitamos verificar el resultado del escaneo aquí,
            // ya que ToolReturnQrScanDialog se encarga de mostrar los detalles de devolución
            // y de decidir si debe cerrarse o reanudar el escaneo.
            // Si llega aquí, significa que ToolReturnQrScanDialog se ha cerrado (ya sea por éxito, error o cancelación interna).
        });
        // --- FIN MODIFICACIÓN CORREGIDA ---

        btnLogout.addActionListener(e -> {
            dispose();
            SwingUtilities.invokeLater(() -> {
                // Asegúrate de que MainApp tiene un método setVisible(true) para mostrar la ventana
                // de inicio de sesión o principal, si es así como lo manejas.
                new MainApp().setVisible(true);
            });
        });
    }

    public Empleado getLoggedInEmployee() {
        return loggedInEmployee;
    }
}