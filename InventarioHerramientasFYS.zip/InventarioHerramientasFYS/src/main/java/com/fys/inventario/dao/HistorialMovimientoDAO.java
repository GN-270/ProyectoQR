package com.fys.inventario.dao;

import com.fys.inventario.model.HistorialMovimiento;
import com.fys.inventario.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class HistorialMovimientoDAO {

    public boolean agregarMovimiento(HistorialMovimiento movimiento) {
        // Esta línea ya la habías cambiado, ¡bien hecho!
        String sql = "INSERT INTO HistorialMovimientos (tipo_accion, fecha_hora, id_empleado, id_herramienta, comentarios) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            // CAMBIO AQUÍ: usar getTipoAccion() y getComentarios()
            pstmt.setString(1, movimiento.getTipoAccion());
            pstmt.setTimestamp(2, Timestamp.valueOf(movimiento.getFechaHora()));
            pstmt.setObject(3, movimiento.getIdEmpleado(), Types.INTEGER);
            pstmt.setObject(4, movimiento.getIdHerramienta(), Types.INTEGER);
            pstmt.setString(5, movimiento.getComentarios()); // CAMBIO AQUÍ

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    movimiento.setIdMovimiento(rs.getInt(1));
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error al agregar movimiento al historial: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return false;
    }

    public List<HistorialMovimiento> obtenerTodosMovimientos() {
        List<HistorialMovimiento> movimientos = new ArrayList<>();
        // CAMBIO AQUÍ: de hm.tipo_movimiento a hm.tipo_accion, y de hm.observaciones a hm.comentarios
        String sql = "SELECT hm.id_movimiento, hm.id_herramienta, h.nombre AS nombre_herramienta, " +
                "hm.id_empleado, e.nombres AS nombre_empleado_nombres, e.apellidos AS nombre_empleado_apellidos, " +
                "hm.tipo_accion, hm.fecha_hora, hm.comentarios " + // <--- CAMBIOS EN SELECT LIST
                "FROM HistorialMovimientos hm " +
                "LEFT JOIN Herramientas h ON hm.id_herramienta = h.id_herramienta " +
                "LEFT JOIN Empleados e ON hm.id_empleado = e.id_empleado " +
                "ORDER BY hm.fecha_hora DESC";

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                // Corrección para id_herramienta
                Integer idHerramienta = null;
                Object objIdHerramienta = rs.getObject("id_herramienta");
                if (objIdHerramienta != null) {
                    // Si es un Long, convertirlo a Integer; si ya es Integer, castearlo directamente.
                    // Esta es la parte crucial que asegura la compatibilidad.
                    if (objIdHerramienta instanceof Long) {
                        idHerramienta = ((Long) objIdHerramienta).intValue();
                    } else if (objIdHerramienta instanceof Integer) {
                        idHerramienta = (Integer) objIdHerramienta;
                    }
                    // Si tienes otros tipos numéricos posibles (ej. Short, BigDecimal), agrégales aquí
                }
                String nombreHerramienta = rs.getString("nombre_herramienta");
                // Ajustar la lógica si la herramienta es nula
                if (nombreHerramienta == null && idHerramienta == null) {
                    nombreHerramienta = "ID (N/A) (Eliminada)";
                } else if (nombreHerramienta == null && idHerramienta != null) {
                    nombreHerramienta = "ID " + idHerramienta + " (Sin nombre)";
                }


                // Corrección para id_empleado
                Integer idEmpleado = null;
                Object objIdEmpleado = rs.getObject("id_empleado");
                if (objIdEmpleado != null) {
                    if (objIdEmpleado instanceof Long) {
                        idEmpleado = ((Long) objIdEmpleado).intValue();
                    } else if (objIdEmpleado instanceof Integer) {
                        idEmpleado = (Integer) objIdEmpleado;
                    }
                }
                String nombreEmpleadoNombres = rs.getString("nombre_empleado_nombres");
                String nombreEmpleadoApellidos = rs.getString("nombre_empleado_apellidos");
                String nombreEmpleadoCompleto = null;

                // Ajustar la lógica si el empleado es nulo
                if (nombreEmpleadoNombres == null && idEmpleado == null) {
                    nombreEmpleadoCompleto = "ID (N/A) (Eliminado)";
                } else if (nombreEmpleadoNombres != null) {
                    nombreEmpleadoCompleto = nombreEmpleadoNombres + " " + (nombreEmpleadoApellidos != null ? nombreEmpleadoApellidos : "");
                } else if (idEmpleado != null) {
                    nombreEmpleadoCompleto = "ID " + idEmpleado + " (Sin nombre)";
                }


                movimientos.add(new HistorialMovimiento(
                        rs.getInt("id_movimiento"),
                        idHerramienta, // Usa el Integer corregido
                        nombreHerramienta,
                        idEmpleado, // Usa el Integer corregido
                        nombreEmpleadoCompleto,
                        rs.getString("tipo_accion"),
                        rs.getTimestamp("fecha_hora").toLocalDateTime(),
                        rs.getString("comentarios")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener todos los movimientos del historial: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return movimientos;
    }
    public List<HistorialMovimiento> buscarMovimientos(Integer idEmpleado, Integer idHerramienta, String tipoMovimiento) {
        List<HistorialMovimiento> movimientos = new ArrayList<>();
        // CAMBIO AQUÍ: de hm.tipo_movimiento a hm.tipo_accion, y de hm.observaciones a hm.comentarios
        StringBuilder sqlBuilder = new StringBuilder("SELECT hm.id_movimiento, hm.id_herramienta, h.nombre AS nombre_herramienta, " +
                "hm.id_empleado, e.nombres AS nombre_empleado_nombres, e.apellidos AS nombre_empleado_apellidos, " +
                "hm.tipo_accion, hm.fecha_hora, hm.comentarios " + // <--- CAMBIOS EN SELECT LIST
                "FROM HistorialMovimientos hm " +
                "LEFT JOIN Herramientas h ON hm.id_herramienta = h.id_herramienta " +
                "LEFT JOIN Empleados e ON hm.id_empleado = e.id_empleado WHERE 1=1");

        List<Object> params = new ArrayList<>();
        // Construir la consulta dinámicamente
        if (idEmpleado != null) {
            sqlBuilder.append(" AND hm.id_empleado = ?");
            params.add(idEmpleado);
        }
        if (idHerramienta != null) {
            sqlBuilder.append(" AND hm.id_herramienta = ?");
            params.add(idHerramienta);
        }
        // CAMBIO AQUÍ: la variable de filtro también debe corresponder a tipo_accion en la DB
        if (tipoMovimiento != null && !tipoMovimiento.isEmpty()) {
            sqlBuilder.append(" AND hm.tipo_accion = ?"); // <--- CAMBIO AQUÍ
            params.add(tipoMovimiento);
        }

        sqlBuilder.append(" ORDER BY hm.fecha_hora DESC");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sqlBuilder.toString());

            // Establecer los parámetros dinámicamente
            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }

            rs = pstmt.executeQuery();

            while (rs.next()) {
                // Corrección para id_herramienta
                Integer currentIdHerramienta = null;
                Object objCurrentIdHerramienta = rs.getObject("id_herramienta");
                if (objCurrentIdHerramienta != null) {
                    if (objCurrentIdHerramienta instanceof Long) {
                        currentIdHerramienta = ((Long) objCurrentIdHerramienta).intValue();
                    } else if (objCurrentIdHerramienta instanceof Integer) {
                        currentIdHerramienta = (Integer) objCurrentIdHerramienta;
                    }
                }
                String nombreHerramienta = rs.getString("nombre_herramienta");
                if (nombreHerramienta == null && currentIdHerramienta == null) {
                    nombreHerramienta = "ID (N/A) (Eliminada)";
                } else if (nombreHerramienta == null && currentIdHerramienta != null) {
                    nombreHerramienta = "ID " + currentIdHerramienta + " (Sin nombre)";
                }


                // Corrección para id_empleado
                Integer currentIdEmpleado = null;
                Object objCurrentIdEmpleado = rs.getObject("id_empleado");
                if (objCurrentIdEmpleado != null) {
                    if (objCurrentIdEmpleado instanceof Long) {
                        currentIdEmpleado = ((Long) objCurrentIdEmpleado).intValue();
                    } else if (objCurrentIdEmpleado instanceof Integer) {
                        currentIdEmpleado = (Integer) objCurrentIdEmpleado;
                    }
                }
                String nombreEmpleadoNombres = rs.getString("nombre_empleado_nombres");
                String nombreEmpleadoApellidos = rs.getString("nombre_empleado_apellidos");
                String nombreEmpleadoCompleto = null;

                if (nombreEmpleadoNombres == null && currentIdEmpleado == null) {
                    nombreEmpleadoCompleto = "ID (N/A) (Eliminado)";
                } else if (nombreEmpleadoNombres != null) {
                    nombreEmpleadoCompleto = nombreEmpleadoNombres + " " + (nombreEmpleadoApellidos != null ? nombreEmpleadoApellidos : "");
                } else if (currentIdEmpleado != null) {
                    nombreEmpleadoCompleto = "ID " + currentIdEmpleado + " (Sin nombre)";
                }

                movimientos.add(new HistorialMovimiento(
                        rs.getInt("id_movimiento"),
                        currentIdHerramienta, // Usa el Integer corregido
                        nombreHerramienta,
                        currentIdEmpleado, // Usa el Integer corregido
                        nombreEmpleadoCompleto,
                        rs.getString("tipo_accion"),
                        rs.getTimestamp("fecha_hora").toLocalDateTime(),
                        rs.getString("comentarios")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar movimientos en el historial: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return movimientos;
    }
}