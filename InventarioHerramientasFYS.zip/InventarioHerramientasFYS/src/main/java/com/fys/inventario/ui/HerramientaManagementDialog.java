package com.fys.inventario.ui;

import com.fys.inventario.dao.HerramientaDAO;
import com.fys.inventario.dao.EmpleadoDAO;
import com.fys.inventario.model.Herramienta;
import com.fys.inventario.model.Empleado; // Necesario para el objeto Empleado
import javax.swing.ImageIcon; // Necesario para cargar imágenes

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import java.util.Vector;

public class HerramientaManagementDialog extends JDialog {

    private HerramientaDAO herramientaDAO;
    private EmpleadoDAO empleadoDAO;
    private DefaultTableModel tableModel;
    private JTable herramientasTable;
    private JLabel qrCodeLabel; // Asegúrate de que este JLabel esté inicializado en initComponents si lo usas.

    // Componentes para el formulario de entrada de datos
    private JTextField txtIdHerramienta;
    private JTextField txtNombre;
    private JTextField txtMarca;
    private JTextArea txtDescripcion;
    private JTextField txtEstado;
    private JComboBox<String> cmbDisponibilidad;
    private JComboBox<EmpleadoComboBoxItem> cmbAsignadoA; // ComboBox para asignar a un empleado
    private JLabel lblQrPath; // Para mostrar la ruta del QR

    private JButton btnAgregar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar;
    private JButton btnMostrarQr;

    public HerramientaManagementDialog(JFrame parent) {
        super(parent, "Gestión de Herramientas", true);
        herramientaDAO = new HerramientaDAO();
        empleadoDAO = new EmpleadoDAO();
        setSize(900, 650);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        initComponents();
        loadHerramientas();
        loadEmpleadosIntoComboBox();

        // Acción al seleccionar una fila de la tabla
        herramientasTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && herramientasTable.getSelectedRow() != -1) {
                int selectedRow = herramientasTable.getSelectedRow();
                txtIdHerramienta.setText(tableModel.getValueAt(selectedRow, 0).toString());
                txtNombre.setText(tableModel.getValueAt(selectedRow, 1).toString());
                txtMarca.setText(tableModel.getValueAt(selectedRow, 2).toString());
                txtDescripcion.setText(tableModel.getValueAt(selectedRow, 3).toString());
                txtEstado.setText(tableModel.getValueAt(selectedRow, 4).toString());
                cmbDisponibilidad.setSelectedItem(tableModel.getValueAt(selectedRow, 5).toString());

                // Cargar el empleado asignado en el ComboBox
                String asignadoANombreCompleto = (String) tableModel.getValueAt(selectedRow, 6);
                selectEmployeeInComboBox(asignadoANombreCompleto);

                Object qrPathValue = tableModel.getValueAt(selectedRow, 7);
                lblQrPath.setText("Ruta QR: " + (qrPathValue != null ? qrPathValue.toString() : "N/A"));

                txtIdHerramienta.setEditable(false);
                btnAgregar.setEnabled(false);
                btnActualizar.setEnabled(true);
                btnEliminar.setEnabled(true);
            }
        });
    }

    private void initComponents() {
        // --- Panel Superior para el Formulario de Entrada ---
        JPanel inputPanel = new JPanel(new GridLayout(8, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Datos de la Herramienta"));

        txtIdHerramienta = new JTextField(15);
        txtIdHerramienta.setEditable(false);
        txtNombre = new JTextField(15);
        txtMarca = new JTextField(15);
        txtDescripcion = new JTextArea(3, 15);
        txtDescripcion.setLineWrap(true);
        txtDescripcion.setWrapStyleWord(true);
        JScrollPane descScrollPane = new JScrollPane(txtDescripcion);

        txtEstado = new JTextField(15);

        String[] disponibilidades = {"Libre", "En uso", "En mantenimiento", "Dada de baja"};
        cmbDisponibilidad = new JComboBox<>(disponibilidades);

        cmbAsignadoA = new JComboBox<>();
        lblQrPath = new JLabel("Ruta QR: N/A");

        // Asegúrate de inicializar qrCodeLabel si lo usas en mostrarQRCode
        // Ejemplo: qrCodeLabel = new JLabel();

        inputPanel.add(new JLabel("ID Herramienta:"));
        inputPanel.add(txtIdHerramienta);
        inputPanel.add(new JLabel("Nombre:"));
        inputPanel.add(txtNombre);
        inputPanel.add(new JLabel("Marca:"));
        inputPanel.add(txtMarca);
        inputPanel.add(new JLabel("Descripción:"));
        inputPanel.add(descScrollPane);
        inputPanel.add(new JLabel("Estado:"));
        inputPanel.add(txtEstado);
        inputPanel.add(new JLabel("Disponibilidad:"));
        inputPanel.add(cmbDisponibilidad);
        inputPanel.add(new JLabel("Asignado a:"));
        inputPanel.add(cmbAsignadoA);
        inputPanel.add(lblQrPath);


        // --- Panel de Botones del Formulario ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnAgregar = new JButton("Agregar");
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");
        btnLimpiar = new JButton("Limpiar Campos");
        btnMostrarQr = new JButton("Mostrar QR");

        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);

        buttonPanel.add(btnAgregar);
        buttonPanel.add(btnActualizar);
        buttonPanel.add(btnEliminar);
        buttonPanel.add(btnLimpiar);
        buttonPanel.add(btnMostrarQr);

        JPanel formPanel = new JPanel(new BorderLayout());
        formPanel.add(inputPanel, BorderLayout.CENTER);
        formPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(formPanel, BorderLayout.NORTH);

        // --- Panel Central para la Tabla de Herramientas ---
        String[] columnNames = {"ID", "Nombre", "Marca", "Descripción", "Estado", "Disponibilidad", "Asignado a", "Ruta QR"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        herramientasTable = new JTable(tableModel);
        herramientasTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(herramientasTable);
        add(scrollPane, BorderLayout.CENTER);

        // --- Eventos de los botones de Acción ---
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarHerramienta();
            }
        });

        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarHerramienta();
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarHerramienta();
            }
        });

        btnLimpiar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });

        btnMostrarQr.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarQrHerramienta();
            }
        });
    }

    private void loadHerramientas() {
        tableModel.setRowCount(0);
        List<Herramienta> herramientas = herramientaDAO.obtenerTodasHerramientas();
        for (Herramienta h : herramientas) {
            tableModel.addRow(new Object[]{
                    h.getIdHerramienta(),
                    h.getNombre(),
                    h.getMarca(),
                    h.getDescripcion(),
                    h.getEstado(),
                    h.getDisponibilidad(),
                    h.getAsignadoANombreCompleto() != null ? h.getAsignadoANombreCompleto() : "Nadie",
                    h.getQrCodePath() != null ? h.getQrCodePath() : "N/A"
            });
        }
    }

    private void loadEmpleadosIntoComboBox() {
        cmbAsignadoA.removeAllItems();
        // La opción "Nadie" tiene un ID de empleado nulo (Integer)
        cmbAsignadoA.addItem(new EmpleadoComboBoxItem(null, "Nadie"));
        List<Empleado> empleados = empleadoDAO.obtenerTodosEmpleados();
        for (Empleado emp : empleados) {
            // emp.getIdEmpleado() ahora devuelve un int, se auto-boxea a Integer
            cmbAsignadoA.addItem(new EmpleadoComboBoxItem(emp.getIdEmpleado(), emp.getNombres() + " " + emp.getApellidos()));
        }
    }

    private void selectEmployeeInComboBox(String fullName) {
        for (int i = 0; i < cmbAsignadoA.getItemCount(); i++) {
            EmpleadoComboBoxItem item = cmbAsignadoA.getItemAt(i);
            if (item.getDisplayName().equals(fullName)) {
                cmbAsignadoA.setSelectedItem(item);
                return;
            }
        }
        cmbAsignadoA.setSelectedItem(cmbAsignadoA.getItemAt(0)); // Seleccionar "Nadie" si no se encuentra
    }

    private void agregarHerramienta() {
        if (!validarCampos()) return;

        String nombre = txtNombre.getText().trim();
        String marca = txtMarca.getText().trim();
        String descripcion = txtDescripcion.getText().trim();
        String estado = txtEstado.getText().trim();
        String disponibilidad = (String) cmbDisponibilidad.getSelectedItem();

        EmpleadoComboBoxItem selectedEmployee = (EmpleadoComboBoxItem) cmbAsignadoA.getSelectedItem();
        // Ahora asignadoAId es Integer, no String
        Integer asignadoAId = (selectedEmployee != null) ? selectedEmployee.getIdEmpleado() : null;


        // Asumiendo que el constructor de Herramienta acepta Integer para asignadoAId
        Herramienta nuevaHerramienta = new Herramienta(nombre, marca, descripcion, estado, disponibilidad, asignadoAId);
        if (herramientaDAO.agregarHerramienta(nuevaHerramienta)) {
            // El ID de la herramienta se asigna después de la inserción en el DAO
            JOptionPane.showMessageDialog(this, "Herramienta agregada exitosamente. ID: " + nuevaHerramienta.getIdHerramienta(), "Éxito", JOptionPane.INFORMATION_MESSAGE);
            loadHerramientas();
            limpiarCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Error al agregar herramienta.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarHerramienta() {
        if (!validarCampos()) return;

        int idHerramienta;
        try {
            idHerramienta = Integer.parseInt(txtIdHerramienta.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "ID de herramienta inválido.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String nombre = txtNombre.getText().trim();
        String marca = txtMarca.getText().trim();
        String descripcion = txtDescripcion.getText().trim();
        String estado = txtEstado.getText().trim();
        String disponibilidad = (String) cmbDisponibilidad.getSelectedItem();

        EmpleadoComboBoxItem selectedEmployee = (EmpleadoComboBoxItem) cmbAsignadoA.getSelectedItem();
        // Ahora asignadoAId es Integer, no String
        Integer asignadoAId = (selectedEmployee != null) ? selectedEmployee.getIdEmpleado() : null;

        String qrPath = (lblQrPath.getText().startsWith("Ruta QR: ") && !lblQrPath.getText().equals("Ruta QR: N/A")) ?
                lblQrPath.getText().substring("Ruta QR: ".length()) : null;


        // Asumiendo que el constructor de Herramienta acepta Integer para asignadoAId
        Herramienta herramientaActualizar = new Herramienta(idHerramienta, nombre, marca, descripcion, estado, disponibilidad, asignadoAId, qrPath);

        if (herramientaDAO.actualizarHerramienta(herramientaActualizar)) {
            JOptionPane.showMessageDialog(this, "Herramienta actualizada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            loadHerramientas();
            limpiarCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Error al actualizar herramienta.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarHerramienta() {
        int idHerramienta;
        try {
            idHerramienta = Integer.parseInt(txtIdHerramienta.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Selecciona una herramienta válida para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Estás seguro de que quieres eliminar la herramienta con ID: " + idHerramienta + "?",
                "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (herramientaDAO.eliminarHerramienta(idHerramienta)) {
                JOptionPane.showMessageDialog(this, "Herramienta eliminada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                loadHerramientas();
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar herramienta. Podría estar asociada a movimientos.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void limpiarCampos() {
        txtIdHerramienta.setText("");
        txtNombre.setText("");
        txtMarca.setText("");
        txtDescripcion.setText("");
        txtEstado.setText("");
        cmbDisponibilidad.setSelectedIndex(0);
        cmbAsignadoA.setSelectedIndex(0);
        lblQrPath.setText("Ruta QR: N/A");

        txtIdHerramienta.setEditable(false);
        btnAgregar.setEnabled(true);
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);
        herramientasTable.clearSelection();
    }

    private boolean validarCampos() {
        if (txtNombre.getText().trim().isEmpty() || txtMarca.getText().trim().isEmpty() ||
                txtDescripcion.getText().trim().isEmpty() || txtEstado.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Los campos Nombre, Marca, Descripción y Estado son obligatorios.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void mostrarQrHerramienta() {
        String qrPath = (lblQrPath.getText().startsWith("Ruta QR: ") && !lblQrPath.getText().equals("Ruta QR: N/A")) ?
                lblQrPath.getText().substring("Ruta QR: ".length()) : null;

        if (qrPath == null || qrPath.isEmpty() || qrPath.equals("N/A")) { // Comprobación adicional por "N/A"
            JOptionPane.showMessageDialog(this, "No hay código QR asociado a esta herramienta o la ruta es inválida.", "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        try {
            ImageIcon qrIcon = new ImageIcon(qrPath);
            // Comprueba si la imagen se cargó correctamente
            if (qrIcon.getIconWidth() == -1) {
                JOptionPane.showMessageDialog(this, "No se pudo cargar la imagen del código QR. Verifique la ruta: " + qrPath, "Error de Carga", JOptionPane.ERROR_MESSAGE);
                return;
            }

            JLabel qrLabelDisplay = new JLabel(qrIcon); // Usar un nuevo JLabel para el diálogo
            qrLabelDisplay.setHorizontalAlignment(SwingConstants.CENTER); // Centrar la imagen

            JDialog qrDialog = new JDialog(this, "Código QR de la Herramienta", true);
            qrDialog.setLayout(new BorderLayout());
            qrDialog.add(new JScrollPane(qrLabelDisplay), BorderLayout.CENTER); // Añadir scroll si la imagen es grande
            qrDialog.pack();
            qrDialog.setLocationRelativeTo(this);
            qrDialog.setVisible(true);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al mostrar la imagen QR: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    // Este método `mostrarQRCode` no parece ser usado en el código proporcionado.
    // Si se usa, asegúrate de que `qrCodeLabel` esté inicializado.
    private void mostrarQRCode(Herramienta herramienta) {
        String qrPath = herramienta.getQrCodePath();
        if (qrCodeLabel == null) {
            qrCodeLabel = new JLabel(); // Inicializar si no se hizo en initComponents
            qrCodeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        }

        if (qrPath != null && !qrPath.isEmpty()) {
            try {
                ImageIcon qrIcon = new ImageIcon(qrPath);
                if (qrIcon.getIconWidth() == -1) { // Error al cargar la imagen
                    System.err.println("Error al cargar la imagen QR (mostrarQRCode): " + qrPath);
                    qrCodeLabel.setIcon(null);
                    qrCodeLabel.setText("QR no disponible");
                } else {
                    qrCodeLabel.setIcon(qrIcon);
                    qrCodeLabel.setText(""); // Limpiar texto si la imagen se carga
                }
            } catch (Exception e) {
                System.err.println("Excepción al cargar la imagen QR (mostrarQRCode): " + e.getMessage());
                qrCodeLabel.setIcon(null);
                qrCodeLabel.setText("QR no disponible (Error)");
                e.printStackTrace();
            }
        } else {
            qrCodeLabel.setIcon(null);
            qrCodeLabel.setText("No hay QR para esta herramienta.");
        }
    }

    /**
     * Clase interna para representar los items del ComboBox de empleados.
     * Esto permite mostrar el nombre completo pero almacenar el ID del empleado como Integer.
     */
    private static class EmpleadoComboBoxItem {
        private Integer idEmpleado; // ¡IMPORTANTE! Cambiado de String a Integer
        private String displayName;

        public EmpleadoComboBoxItem(Integer idEmpleado, String displayName) { // Recibe Integer
            this.idEmpleado = idEmpleado;
            this.displayName = displayName;
        }

        public Integer getIdEmpleado() { // Retorna Integer
            return idEmpleado;
        }

        public String getDisplayName() {
            return displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }
}