package com.fys.inventario.ui;

import com.fys.inventario.dao.EmpleadoDAO; // Asegúrate de que este import sea correcto
import com.fys.inventario.model.Empleado; // Asegúrate de que este import sea correcto

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class EmployeeViewerDialog extends JDialog {

    private EmpleadoDAO empleadoDAO;
    private DefaultTableModel tableModel;
    private JTable employeeTable;

    // Constructor que acepta un JDialog como parent (para que UserDashboardDialog pueda llamarlo)
    public EmployeeViewerDialog(java.awt.Dialog parent) {
        super(parent, "Ver Empleados", true); // 'true' para hacerlo modal
        empleadoDAO = new EmpleadoDAO();

        setSize(700, 500); // Tamaño adecuado
        setLocationRelativeTo(parent); // Centrar respecto al padre
        setDefaultCloseOperation(DISPOSE_ON_CLOSE); // Cerrar solo este diálogo

        initComponents();
        loadEmployees(); // Cargar los datos al iniciar el diálogo
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10)); // Margen entre componentes

        // Título del diálogo
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel titleLabel = new JLabel("Lista de Empleados del Sistema");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        topPanel.add(titleLabel);
        add(topPanel, BorderLayout.NORTH);

        // Configuración de la tabla
        // Las columnas deben coincidir con lo que obtienes de EmpleadoDAO.obtenerTodosEmpleados()
        String[] columnNames = {"ID", "DNI", "Nombres", "Apellidos", "Labor"}; // Quitamos QR path para simplicidad en la tabla
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // HACEMOS QUE LA TABLA SEA DE SOLO LECTURA
            }
        };
        employeeTable = new JTable(tableModel);
        employeeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // Permite una sola selección (aunque no se usará para edición)
        employeeTable.getTableHeader().setReorderingAllowed(false); // Evita que se reordenen las columnas

        // Ajustar el ancho preferido de las columnas
        employeeTable.getColumnModel().getColumn(0).setPreferredWidth(30);  // ID
        employeeTable.getColumnModel().getColumn(1).setPreferredWidth(80);  // DNI
        employeeTable.getColumnModel().getColumn(2).setPreferredWidth(120); // Nombres
        employeeTable.getColumnModel().getColumn(3).setPreferredWidth(120); // Apellidos
        employeeTable.getColumnModel().getColumn(4).setPreferredWidth(100); // Labor

        JScrollPane scrollPane = new JScrollPane(employeeTable);
        add(scrollPane, BorderLayout.CENTER);

        // Botón de cerrar
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        JButton closeButton = new JButton("Cerrar");
        closeButton.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        closeButton.addActionListener(e -> dispose()); // Cierra el diálogo
        bottomPanel.add(closeButton);
        add(bottomPanel, BorderLayout.SOUTH);
    }

    private void loadEmployees() {
        tableModel.setRowCount(0); // Limpia la tabla antes de cargar nuevos datos
        List<Empleado> empleados = empleadoDAO.obtenerTodosEmpleados(); // Llama al DAO para obtener los empleados

        for (Empleado empleado : empleados) {
            // Añadir fila con los datos del empleado
            tableModel.addRow(new Object[]{
                    empleado.getIdEmpleado(),
                    empleado.getDni(),
                    empleado.getNombres(),
                    empleado.getApellidos(),
                    empleado.getLabor() // Asegúrate de que tu Empleado model tenga getLabor()
                    // empleado.getQrCodePath() // No lo mostramos en la tabla para simplicidad
            });
        }
    }
}