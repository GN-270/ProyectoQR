package com.fys.inventario.util;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;

public class QRCodeGenerator {

    private static final String QR_CODE_DIRECTORY = "qrcodes"; // Nombre de la carpeta donde se guardarán los QR
    private static final int QR_CODE_SIZE = 200; // Tamaño de la imagen del QR (ancho y alto en píxeles)

    public static String generateAndSaveQRCode(String data, String fileName) throws IOException, WriterException {
        // Asegurarse de que el directorio de QR exista
        File directory = new File(QR_CODE_DIRECTORY);
        if (!directory.exists()) {
            directory.mkdirs(); // Crea el directorio y sus padres si no existen
        }

        // Configuración para la generación del QR
        Map<EncodeHintType, Object> hints = new HashMap<>();
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H); // Nivel de corrección de error (L, M, Q, H)

        QRCodeWriter qrCodeWriter = new QRCodeWriter();
        BitMatrix bitMatrix = qrCodeWriter.encode(data, BarcodeFormat.QR_CODE, QR_CODE_SIZE, QR_CODE_SIZE, hints);

        // Ruta completa donde se guardará el archivo
        String filePath = QR_CODE_DIRECTORY + File.separator + fileName + ".png";
        Path path = Paths.get(filePath);

        // Escribir la matriz de bits como imagen PNG
        MatrixToImageWriter.writeToPath(bitMatrix, "PNG", path);

        return filePath; // Retorna la ruta relativa del archivo guardado
    }

    public static void main(String[] args) {
        // Ejemplo de uso
        try {
            String dataToEncode = "ID_HERRAMIENTA_123"; // Podría ser el ID de la herramienta
            String fileName = "herramienta_123_qr"; // Nombre del archivo del QR
            String qrPath = generateAndSaveQRCode(dataToEncode, fileName);
            System.out.println("QR Code generado y guardado en: " + qrPath);
        } catch (WriterException | IOException e) {
            e.printStackTrace();
        }
    }
}