package com.fys.inventario.ui;

import com.fys.inventario.dao.EmpleadoDAO;
import com.fys.inventario.model.Empleado;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.LuminanceSource;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public class UserLoginQrCameraDialog extends JDialog implements Runnable, ThreadFactory {

    private EmpleadoDAO empleadoDAO;
    private Webcam webcam = null;
    private WebcamPanel panel = null;
    private JTextArea resultArea = null;
    private JLabel lblScanStatus;

    private Executor executor = Executors.newSingleThreadExecutor(this);

    public enum LoginResult {
        SUCCESS,
        FAILURE,
        CANCELLED
    }

    private LoginResult result = LoginResult.CANCELLED;
    private Empleado loggedInEmployee = null;

    public UserLoginQrCameraDialog(JFrame parent) {
        super(parent, "Iniciar Sesión de Usuario (Cámara QR)", true);
        empleadoDAO = new EmpleadoDAO();
        setSize(600, 500); // Tamaño adecuado para la webcam
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent windowEvent) {
                if (webcam != null && webcam.isOpen()) {
                    webcam.close(); // Cierra la webcam al cerrar el diálogo
                }
            }
        });

        initComponents();
        initWebcam();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        lblScanStatus = new JLabel("Esperando código QR...");
        lblScanStatus.setFont(new Font("Segoe UI", Font.BOLD, 16));
        topPanel.add(lblScanStatus);
        add(topPanel, BorderLayout.NORTH);

        resultArea = new JTextArea();
        resultArea.setEditable(false);
        resultArea.setLineWrap(true);
        resultArea.setWrapStyleWord(true);
        resultArea.setBorder(BorderFactory.createTitledBorder("Resultado del Escaneo"));
        add(new JScrollPane(resultArea), BorderLayout.SOUTH); // Añadimos un scroll pane para el área de texto
    }

    private void initWebcam() {
        webcam = Webcam.getDefault();
        if (webcam != null) {
            webcam.setViewSize(WebcamResolution.VGA.getSize()); // 640x480

            panel = new WebcamPanel(webcam);
            panel.setFPSLimit(10); // Frame rate para la visualización
            panel.setMirrored(true); // Espejo para que el usuario se vea correctamente

            add(panel, BorderLayout.CENTER);
            pack(); // Ajusta el tamaño de la ventana al contenido

            executor.execute(this); // Inicia el hilo de escaneo
        } else {
            JOptionPane.showMessageDialog(this, "No se encontró ninguna cámara web.", "Error de Cámara", JOptionPane.ERROR_MESSAGE);
            lblScanStatus.setText("Cámara no detectada.");
            result = LoginResult.FAILURE;
            // No se abre el diálogo si no hay cámara
            SwingUtilities.invokeLater(() -> dispose()); // Cierra inmediatamente si no hay cámara
        }
    }

    @Override
    public void run() {
        do {
            try {
                Thread.sleep(100); // Pequeña pausa para no saturar la CPU
            } catch (InterruptedException e) {
                // Thread.currentThread().interrupt(); // Restore the interrupted status
                return; // Salir del bucle si el hilo es interrumpido
            }

            BufferedImage image = null;

            if (webcam.isOpen()) { // Asegúrate de que la webcam esté abierta antes de capturar
                image = webcam.getImage(); // Captura la imagen de la cámara
            } else {
                return; // Salir si la webcam se cerró
            }

            if (image == null) {
                continue; // No hay imagen aún, seguir esperando
            }

            LuminanceSource source = new BufferedImageLuminanceSource(image);
            BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
            Result qrResult = null;

            try {
                qrResult = new MultiFormatReader().decode(bitmap);
            } catch (NotFoundException e) {
                // QR no encontrado en este frame, no hacer nada y seguir escaneando
            } catch (Exception e) {
                System.err.println("Error general al leer QR: " + e.getMessage());
                // Puedes mostrar un error menos intrusivo si es un error diferente a NotFound
            }

            if (qrResult != null) {
                String qrContent = qrResult.getText();
                SwingUtilities.invokeLater(() -> resultArea.setText("QR Leído: " + qrContent));

                try {
                    int employeeId = Integer.parseInt(qrContent.trim());
                    Empleado employee = empleadoDAO.obtenerEmpleadoPorId(employeeId);

                    if (employee != null) {
                        loggedInEmployee = employee;
                        result = LoginResult.SUCCESS;
                        SwingUtilities.invokeLater(() -> {
                            JOptionPane.showMessageDialog(UserLoginQrCameraDialog.this,
                                    "Bienvenido, " + employee.getNombres() + " " + employee.getApellidos() + "!",
                                    "Login Exitoso", JOptionPane.INFORMATION_MESSAGE);
                            if (webcam != null && webcam.isOpen()) {
                                webcam.close(); // Cierra la webcam después del login exitoso
                            }
                            dispose(); // Cierra este diálogo
                        });
                        break; // Salir del bucle do-while
                    } else {
                        SwingUtilities.invokeLater(() -> {
                            lblScanStatus.setText("QR no válido: Empleado no encontrado. Reintente...");
                            resultArea.setText("Contenido QR: " + qrContent + "\nEmpleado no encontrado en DB.");
                        });
                    }
                } catch (NumberFormatException e) {
                    SwingUtilities.invokeLater(() -> {
                        lblScanStatus.setText("QR no válido: Contenido numérico inválido. Reintente...");
                        resultArea.setText("Contenido QR: " + qrContent + "\nNo es un ID de empleado válido.");
                    });
                }
            } else {
                SwingUtilities.invokeLater(() -> lblScanStatus.setText("Esperando código QR..."));
            }
        } while (webcam != null && webcam.isOpen() && result != LoginResult.SUCCESS);
    }

    @Override
    public Thread newThread(Runnable r) {
        Thread t = new Thread(r, "QR-Scanner-Thread");
        t.setDaemon(true); // Hilo demonio, se cerrará con la aplicación
        return t;
    }

    public LoginResult getLoginResult() {
        return result;
    }

    public Empleado getLoggedInEmployee() {
        return loggedInEmployee;
    }
}