package com.fys.inventario.main;

import com.fys.inventario.dao.EmpleadoDAO;
import com.fys.inventario.dao.HerramientaDAO;
import com.fys.inventario.model.Empleado;
import com.fys.inventario.model.Herramienta;

import java.util.List;
import java.util.Scanner;

public class MainTestHerramienta {

    public static void main(String[] args) {
        HerramientaDAO herramientaDAO = new HerramientaDAO();
        EmpleadoDAO empleadoDAO = new EmpleadoDAO();
        Scanner scanner = new Scanner(System.in);

        System.out.println("--- PRUEBA DE HERRAMIENTADAO ---");

        // --- 1. AGREGAR UNA HERRAMIENTA ---
        System.out.println("\n--- Agregando una nueva herramienta ---");
        // Constructor: Herramienta(String nombre, String marca, String descripcion, String estado, String disponibilidad, Integer asignadoAIdEmpleado)
        // Para una herramienta nueva, la disponibilidad inicial suele ser "Libre" y no está asignada a nadie (null).
        Herramienta nuevaHerramienta = new Herramienta("Martillo de bola", "Truper", "Martillo con cabeza esférica de 24oz", "Excelente", "Libre", null);

        if (herramientaDAO.agregarHerramienta(nuevaHerramienta)) {
            System.out.println("Herramienta '" + nuevaHerramienta.getNombre() + "' agregada exitosamente con ID: " + nuevaHerramienta.getIdHerramienta());
        } else {
            System.out.println("Fallo al agregar la herramienta.");
        }

        // --- 2. OBTENER TODAS LAS HERRAMIENTAS ---
        System.out.println("\n--- Listado de todas las herramientas ---");
        listarHerramientas(herramientaDAO.obtenerTodasHerramientas());

        // --- 3. OBTENER UNA HERRAMIENTA POR ID ---
        // Intentaremos buscar la herramienta que acabamos de agregar por su ID
        System.out.println("\n--- Buscando una herramienta por ID (ej: " + nuevaHerramienta.getIdHerramienta() + ") ---");
        Herramienta herramientaBuscadaId = herramientaDAO.obtenerHerramientaPorId(nuevaHerramienta.getIdHerramienta());
        if (herramientaBuscadaId != null) {
            System.out.println("Herramienta encontrada por ID: " + herramientaBuscadaId.getNombre() + ", Marca: " + herramientaBuscadaId.getMarca() + ", Disponibilidad: " + herramientaBuscadaId.getDisponibilidad() + ", Asignado a: " + (herramientaBuscadaId.getAsignadoANombreCompleto() != null ? herramientaBuscadaId.getAsignadoANombreCompleto() : "Nadie"));
        } else {
            System.out.println("Herramienta con ID " + nuevaHerramienta.getIdHerramienta() + " no encontrada.");
        }

        // --- 4. BUSCAR HERRAMIENTAS POR NOMBRE ---
        System.out.println("\n--- Buscando herramientas que contengan 'Llave' en el nombre ---");
        List<Herramienta> llaves = herramientaDAO.buscarHerramientasPorNombre("Llave");
        if (llaves.isEmpty()) {
            System.out.println("No se encontraron herramientas con 'Llave'.");
        } else {
            listarHerramientas(llaves);
        }

        // --- 5. ACTUALIZAR UNA HERRAMIENTA (Ej: 'Taladro Percutor') ---
        System.out.println("\n--- Actualizando la descripción de una herramienta existente ---");
        System.out.print("Introduce el ID de la herramienta a actualizar (ej: 2 para Taladro Percutor): ");
        int idHerramientaActualizar = 0;
        try {
            idHerramientaActualizar = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.err.println("ID de herramienta inválido. Debe ser un número entero.");
            scanner.close();
            return;
        }

        Herramienta herramientaActualizar = herramientaDAO.obtenerHerramientaPorId(idHerramientaActualizar);
        if (herramientaActualizar != null) {
            System.out.println("Herramienta seleccionada: " + herramientaActualizar.getNombre() + ". Nueva descripción: ");
            herramientaActualizar.setDescripcion("Descripción actualizada: " + herramientaActualizar.getNombre() + " potente y versátil.");
            herramientaActualizar.setEstado("Excelente"); // Se mejoró el estado

            if (herramientaDAO.actualizarHerramienta(herramientaActualizar)) {
                System.out.println("Herramienta ID " + idHerramientaActualizar + " actualizada exitosamente.");
            } else {
                System.out.println("Fallo al actualizar la herramienta ID " + idHerramientaActualizar + ".");
            }
        } else {
            System.out.println("Herramienta con ID " + idHerramientaActualizar + " no encontrada para actualizar.");
        }

        // --- 6. ASIGNAR UNA HERRAMIENTA A UN EMPLEADO (Actualizar disponibilidad) ---
        System.out.println("\n--- Asignando una herramienta a un empleado ---");
        System.out.print("Introduce el ID del empleado para la asignación (ej: 1): ");
        int idEmpleadoAsignar = 0;
        try {
            idEmpleadoAsignar = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.err.println("ID de empleado inválido. Debe ser un número entero.");
            scanner.close();
            return;
        }

        System.out.print("Introduce el ID de la herramienta a asignar (ej: 1 para Llave Ajustable): ");
        int idHerramientaAsignar = 0;
        try {
            idHerramientaAsignar = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.err.println("ID de herramienta inválido. Debe ser un número entero.");
            scanner.close();
            return;
        }

        Empleado empleadoAsignacion = empleadoDAO.obtenerEmpleadoPorId(idEmpleadoAsignar);
        Herramienta herramientaAsignacion = herramientaDAO.obtenerHerramientaPorId(idHerramientaAsignar);

        if (empleadoAsignacion != null && herramientaAsignacion != null) {
            // El método actualizarDisponibilidad espera Integer para el ID del empleado, int se autoboxea
            if (herramientaDAO.actualizarDisponibilidad(herramientaAsignacion.getIdHerramienta(), "En uso", empleadoAsignacion.getIdEmpleado())) {
                System.out.println("Herramienta '" + herramientaAsignacion.getNombre() + "' asignada a " + empleadoAsignacion.getNombres() + " " + empleadoAsignacion.getApellidos() + ".");
            } else {
                System.out.println("Fallo al asignar la herramienta '" + herramientaAsignacion.getNombre() + "'.");
            }
        } else {
            System.out.println("No se encontró el empleado (ID: " + idEmpleadoAsignar + ") o la herramienta (ID: " + idHerramientaAsignar + ") para la asignación.");
        }

        // Volvemos a listar para ver los cambios de actualización y asignación
        System.out.println("\n--- Listado de herramientas después de actualizar y asignar ---");
        listarHerramientas(herramientaDAO.obtenerTodasHerramientas());

        // --- 7. DEVOLVER/LIBERAR UNA HERRAMIENTA ---
        System.out.println("\n--- Liberando una herramienta ---");
        System.out.print("Introduce el ID de la herramienta a liberar (ej: 1 para Llave Ajustable): ");
        int idHerramientaLiberar = 0;
        try {
            idHerramientaLiberar = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.err.println("ID de herramienta inválido. Debe ser un número entero.");
            scanner.close();
            return;
        }

        Herramienta herramientaLiberar = herramientaDAO.obtenerHerramientaPorId(idHerramientaLiberar);
        if (herramientaLiberar != null) {
            // null para liberar la asignación de empleado
            if (herramientaDAO.actualizarDisponibilidad(herramientaLiberar.getIdHerramienta(), "Libre", null)) {
                System.out.println("Herramienta '" + herramientaLiberar.getNombre() + "' liberada exitosamente.");
            } else {
                System.out.println("Fallo al liberar la herramienta '" + herramientaLiberar.getNombre() + "'.");
            }
        } else {
            System.out.println("Herramienta con ID " + idHerramientaLiberar + " no encontrada para liberar.");
        }


        // --- 8. ELIMINAR UNA HERRAMIENTA (¡Ten cuidado si tiene historial de movimientos!) ---
        System.out.println("\n--- Intentando eliminar la herramienta recién agregada (ID: " + nuevaHerramienta.getIdHerramienta() + ") ---");

        System.out.print("¿Deseas intentar eliminar la herramienta '" + nuevaHerramienta.getNombre() + "' con ID " + nuevaHerramienta.getIdHerramienta() + "? (s/n): ");
        String confirmacion = scanner.nextLine();
        if (confirmacion.equalsIgnoreCase("s")) {
            if (herramientaDAO.eliminarHerramienta(nuevaHerramienta.getIdHerramienta())) {
                System.out.println("Herramienta con ID " + nuevaHerramienta.getIdHerramienta() + " eliminada exitosamente.");
            } else {
                System.out.println("Fallo al eliminar la herramienta con ID " + nuevaHerramienta.getIdHerramienta() + ". (Podría tener dependencias en HistorialMovimientos)");
            }
        } else {
            System.out.println("Eliminación de herramienta cancelada.");
        }


        System.out.println("\n--- Listado final de todas las herramientas ---");
        listarHerramientas(herramientaDAO.obtenerTodasHerramientas());

        scanner.close();
        System.out.println("\n--- FIN DE LA PRUEBA DE HERRAMIENTADADO ---");
    }

    // Método auxiliar para imprimir la lista de herramientas
    private static void listarHerramientas(List<Herramienta> herramientas) {
        if (herramientas == null || herramientas.isEmpty()) {
            System.out.println("  No hay herramientas en la base de datos.");
        } else {
            for (Herramienta h : herramientas) {
                String asignadoInfo = (h.getAsignadoANombreCompleto() != null && !h.getAsignadoANombreCompleto().isEmpty()) ?
                        " (Asignado a: " + h.getAsignadoANombreCompleto() + ")" : "";
                System.out.println("ID: " + h.getIdHerramienta() + ", Nombre: " + h.getNombre() + ", Marca: " + h.getMarca() +
                        ", Estado: " + h.getEstado() + ", Disponibilidad: " + h.getDisponibilidad() + asignadoInfo);
            }
        }
    }
}