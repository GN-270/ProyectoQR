package com.fys.inventario.main;

import com.fys.inventario.util.QrCodeUtil;
import com.fys.inventario.util.QrCodeUtil.QrType; // Importamos el enum QrType
import com.google.zxing.WriterException; // Importar esta excepción
import java.io.File;
import java.io.IOException; // Importar esta excepción
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class MainTestQr {

    public static void main(String[] args) {
        System.out.println("--- PRUEBA DE QRCODEUTIL ---");

        // --- 1. Generar QR para un Empleado ---
        String empleadoId = "00000005"; // Un ID de empleado de ejemplo
        String empleadoData = "EMPLEADO|" + empleadoId; // Contenido del QR: Tipo|ID
        String empleadoFileName = empleadoId; // Nombre del archivo: ID del empleado

        System.out.println("\nGenerando QR para Empleado con ID: " + empleadoId);
        String empleadoQrPath = null;
        try {
            empleadoQrPath = QrCodeUtil.generateAndSaveQrCode(empleadoData, empleadoFileName, QrType.EMPLEADO);

            if (empleadoQrPath != null) {
                System.out.println("QR de empleado generado exitosamente. Ruta: " + empleadoQrPath);
                // Verificar si el archivo realmente existe
                if (Files.exists(Paths.get(empleadoQrPath))) {
                    System.out.println("El archivo QR de empleado existe en el sistema de archivos.");
                } else {
                    System.err.println("¡ADVERTENCIA! El archivo QR de empleado no se encontró en la ruta esperada.");
                }
            } else {
                System.err.println("Fallo al generar el QR para el empleado (ruta null).");
            }
        } catch (IOException | WriterException e) { // Capturamos ambas excepciones
            System.err.println("Error al generar el QR para el empleado " + empleadoId + ": " + e.getMessage());
            e.printStackTrace();
        }

        // --- 2. Generar QR para una Herramienta ---
        int herramientaId = 101; // Un ID de herramienta de ejemplo
        String herramientaData = "HERRAMIENTA|" + herramientaId; // Contenido del QR: Tipo|ID
        String herramientaFileName = "H" + herramientaId; // Nombre del archivo: H + ID de herramienta

        System.out.println("\nGenerando QR para Herramienta con ID: " + herramientaId);
        String herramientaQrPath = null;
        try {
            herramientaQrPath = QrCodeUtil.generateAndSaveQrCode(herramientaData, herramientaFileName, QrType.HERRAMIENTA);

            if (herramientaQrPath != null) {
                System.out.println("QR de herramienta generado exitosamente. Ruta: " + herramientaQrPath);
                // Verificar si el archivo realmente existe
                if (Files.exists(Paths.get(herramientaQrPath))) {
                    System.out.println("El archivo QR de herramienta existe en el sistema de archivos.");
                } else {
                    System.err.println("¡ADVERTENCIA! El archivo QR de herramienta no se encontró en la ruta esperada.");
                }
            } else {
                System.err.println("Fallo al generar el QR para la herramienta (ruta null).");
            }
        } catch (IOException | WriterException e) { // Capturamos ambas excepciones
            System.err.println("Error al generar el QR para la herramienta " + herramientaId + ": " + e.getMessage());
            e.printStackTrace();
        }

        System.out.println("\n--- FIN DE LA PRUEBA DE QRCODEUTIL ---");
        System.out.println("Por favor, revisa la carpeta 'resources/qrcodes/' de tu proyecto para ver los archivos generados.");
    }
}