package com.fys.inventario.dao;

import com.fys.inventario.model.Herramienta;
import com.fys.inventario.model.Empleado;
import com.fys.inventario.util.DatabaseConnection;
import com.fys.inventario.util.QrCodeUtil;
import com.fys.inventario.util.QrCodeUtil.QrType;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import com.google.zxing.WriterException;

/**
 * Clase DAO (Data Access Object) para la entidad Herramienta.
 * Provee métodos para interactuar con la tabla 'Herramientas' en la base de datos.
 */
public class HerramientaDAO {

    /**
     * Agrega una nueva herramienta a la base de datos.
     * El ID de la herramienta se generará automáticamente en la DB,
     * luego se genera y guarda el QR con ese ID.
     *
     * @param herramienta El objeto Herramienta a agregar.
     * @return true si la herramienta fue agregada exitosamente, false en caso contrario.
     */
    public boolean agregarHerramienta(Herramienta herramienta) {
        String sql = "INSERT INTO Herramientas (nombre, marca, descripcion, estado, disponibilidad, asignado_a, qr_code_path) VALUES (?, ?, ?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            pstmt.setString(1, herramienta.getNombre());
            pstmt.setString(2, herramienta.getMarca());
            pstmt.setString(3, herramienta.getDescripcion());
            pstmt.setString(4, herramienta.getEstado());
            pstmt.setString(5, herramienta.getDisponibilidad());

            if (herramienta.getAsignadoAIdEmpleado() != null) {
                pstmt.setInt(6, herramienta.getAsignadoAIdEmpleado());
            } else {
                pstmt.setNull(6, java.sql.Types.INTEGER);
            }
            pstmt.setString(7, null);

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    // Si id_herramienta es BIGINT en DB, podría ser Long. Usar getLong(1) y luego intValue()
                    // Si es INT, getInt(1) está bien. Para seguridad, se puede usar getLong y luego convertir.
                    herramienta.setIdHerramienta(rs.getInt(1)); // Asume que id_herramienta es INT en DB

                    String qrContent = String.valueOf(herramienta.getIdHerramienta());
                    String qrFileName = "qr_herramienta_" + herramienta.getIdHerramienta();
                    String qrPath = null;
                    try {
                        qrPath = QrCodeUtil.generateAndSaveQrCode(qrContent, qrFileName, QrType.HERRAMIENTA);
                    } catch (IOException | WriterException e) {
                        System.err.println("Error al generar o guardar el código QR para la herramienta " + herramienta.getIdHerramienta() + ": " + e.getMessage());
                        e.printStackTrace();
                    }

                    if (qrPath != null) {
                        String updateSql = "UPDATE Herramientas SET qr_code_path = ? WHERE id_herramienta = ?";
                        try (PreparedStatement updatePstmt = conn.prepareStatement(updateSql)) {
                            updatePstmt.setString(1, qrPath);
                            updatePstmt.setInt(2, herramienta.getIdHerramienta());
                            updatePstmt.executeUpdate();
                            herramienta.setQrCodePath(qrPath);
                        }
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error al agregar herramienta: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Obtiene una lista de todas las herramientas con el nombre completo del empleado asignado.
     * @return Una lista de objetos Herramienta.
     */
    public List<Herramienta> obtenerTodasHerramientas() {
        List<Herramienta> herramientas = new ArrayList<>();
        String sql = "SELECT h.id_herramienta, h.nombre, h.marca, h.descripcion, h.estado, h.disponibilidad, h.asignado_a, h.qr_code_path, " +
                "e.nombres, e.apellidos " +
                "FROM Herramientas h LEFT JOIN Empleados e ON h.asignado_a = e.id_empleado";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                int idHerramienta = rs.getInt("id_herramienta");
                String nombre = rs.getString("nombre");
                String marca = rs.getString("marca");
                String descripcion = rs.getString("descripcion");
                String estado = rs.getString("estado");
                String disponibilidad = rs.getString("disponibilidad");

                // --- INICIO DE CORRECCIÓN (Línea 131 original) ---
                // Leer 'asignado_a' como Long primero para manejar BIGINT de la DB
                // Luego convertir a Integer si no es null
                Integer asignadoAIdEmpleado = null;
                Object asignadoAObj = rs.getObject("asignado_a");
                if (asignadoAObj instanceof Long) {
                    asignadoAIdEmpleado = ((Long) asignadoAObj).intValue();
                } else if (asignadoAObj instanceof Integer) {
                    asignadoAIdEmpleado = (Integer) asignadoAObj;
                } else if (asignadoAObj != null) {
                    // Manejar otros tipos si es necesario, o lanzar un error
                    System.err.println("Advertencia: 'asignado_a' no es Long ni Integer, es " + asignadoAObj.getClass().getName());
                    // Puedes decidir qué hacer aquí, por ahora lo dejaremos null si el tipo es inesperado
                }
                // --- FIN DE CORRECCIÓN ---

                String qrCodePath = rs.getString("qr_code_path");

                Herramienta herramienta = new Herramienta(idHerramienta, nombre, marca, descripcion, estado, disponibilidad, asignadoAIdEmpleado, qrCodePath);

                String nombreEmpleadoAsignado = rs.getString("nombres");
                String apellidosEmpleadoAsignado = rs.getString("apellidos");
                if (nombreEmpleadoAsignado != null && apellidosEmpleadoAsignado != null) {
                    herramienta.setAsignadoANombreCompleto(nombreEmpleadoAsignado + " " + apellidosEmpleadoAsignado);
                } else {
                    herramienta.setAsignadoANombreCompleto("N/A");
                }
                herramientas.add(herramienta);
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener todas las herramientas: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return herramientas;
    }

    /**
     * Obtiene una herramienta por su ID.
     * @param idHerramienta El ID de la herramienta a buscar.
     * @return El objeto Herramienta si se encuentra, o null si no existe.
     */
    public Herramienta obtenerHerramientaPorId(int idHerramienta) {
        String sql = "SELECT h.id_herramienta, h.nombre, h.marca, h.descripcion, h.estado, h.disponibilidad, h.asignado_a, h.qr_code_path, " +
                "e.nombres, e.apellidos " +
                "FROM Herramientas h LEFT JOIN Empleados e ON h.asignado_a = e.id_empleado WHERE h.id_herramienta = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Herramienta herramienta = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, idHerramienta);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                // --- CORRECCIÓN similar aquí ---
                Integer asignadoAIdEmpleado = null;
                Object asignadoAObj = rs.getObject("asignado_a");
                if (asignadoAObj instanceof Long) {
                    asignadoAIdEmpleado = ((Long) asignadoAObj).intValue();
                } else if (asignadoAObj instanceof Integer) {
                    asignadoAIdEmpleado = (Integer) asignadoAObj;
                }
                // --- FIN DE CORRECCIÓN ---

                herramienta = new Herramienta(
                        idHerramienta,
                        rs.getString("nombre"),
                        rs.getString("marca"),
                        rs.getString("descripcion"),
                        rs.getString("estado"),
                        rs.getString("disponibilidad"),
                        asignadoAIdEmpleado,
                        rs.getString("qr_code_path")
                );
                String nombreEmpleadoAsignado = rs.getString("nombres");
                String apellidosEmpleadoAsignado = rs.getString("apellidos");
                if (nombreEmpleadoAsignado != null && apellidosEmpleadoAsignado != null) {
                    herramienta.setAsignadoANombreCompleto(nombreEmpleadoAsignado + " " + apellidosEmpleadoAsignado);
                } else {
                    herramienta.setAsignadoANombreCompleto("N/A");
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener herramienta por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return herramienta;
    }

    /**
     * Actualiza la disponibilidad y, opcionalmente, la asignación de una herramienta a un empleado.
     * Este método es redundante si `actualizarHerramienta` ya maneja todos los campos.
     * Considera si realmente lo necesitas o si `actualizarHerramienta` es suficiente.
     * Si lo mantienes, debe manejar el cierre de la conexión.
     *
     * @param idHerramienta El ID de la herramienta a actualizar.
     * @param disponibilidad El nuevo estado de disponibilidad (ej. "Libre", "En uso", "En mantenimiento").
     * @param idEmpleado El ID del empleado al que se asigna la herramienta. Puede ser null si la herramienta se libera.
     * @return true si la actualización fue exitosa, false en caso contrario.
     */
    public boolean actualizarDisponibilidad(int idHerramienta, String disponibilidad, Integer idEmpleado) {
        String sql = "UPDATE Herramientas SET disponibilidad = ?, asignado_a = ? WHERE id_herramienta = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        boolean exito = false;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, disponibilidad);

            if (idEmpleado == null) {
                pstmt.setNull(2, Types.INTEGER);
            } else {
                pstmt.setInt(2, idEmpleado);
            }
            pstmt.setInt(3, idHerramienta);

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                System.out.println("Disponibilidad de herramienta " + idHerramienta + " actualizada a '" + disponibilidad + "'.");
                exito = true;
            }
        } catch (SQLException e) {
            System.err.println("Error de SQL al actualizar disponibilidad de herramienta: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (pstmt != null) { try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); } }
            DatabaseConnection.closeConnection(conn);
        }
        return exito;
    }


    /**
     * Actualiza la información de una herramienta existente en la base de datos.
     * @param herramienta El objeto Herramienta con la información actualizada.
     * @return true si la herramienta fue actualizada exitosamente, false en caso contrario.
     */
    public boolean actualizarHerramienta(Herramienta herramienta) {
        String sql = "UPDATE Herramientas SET nombre = ?, marca = ?, descripcion = ?, estado = ?, disponibilidad = ?, asignado_a = ?, qr_code_path = ? WHERE id_herramienta = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);

            if (herramienta.getQrCodePath() == null || herramienta.getQrCodePath().isEmpty()) {
                String qrContent = String.valueOf(herramienta.getIdHerramienta());
                String qrFileName = "qr_herramienta_" + herramienta.getIdHerramienta();
                String qrPath = null;
                try {
                    qrPath = QrCodeUtil.generateAndSaveQrCode(qrContent, qrFileName, QrType.HERRAMIENTA);
                } catch (IOException | WriterException e) {
                    System.err.println("Error al generar/re-generar el código QR para la herramienta " + herramienta.getIdHerramienta() + ": " + e.getMessage());
                    e.printStackTrace();
                }
                if (qrPath != null) {
                    herramienta.setQrCodePath(qrPath);
                }
            }

            pstmt.setString(1, herramienta.getNombre());
            pstmt.setString(2, herramienta.getMarca());
            pstmt.setString(3, herramienta.getDescripcion());
            pstmt.setString(4, herramienta.getEstado());
            pstmt.setString(5, herramienta.getDisponibilidad());

            if (herramienta.getAsignadoAIdEmpleado() != null) {
                pstmt.setInt(6, herramienta.getAsignadoAIdEmpleado());
            } else {
                pstmt.setNull(6, java.sql.Types.INTEGER);
            }
            pstmt.setString(7, herramienta.getQrCodePath());
            pstmt.setInt(8, herramienta.getIdHerramienta());

            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar herramienta: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
    }

    /**
     * Busca herramientas por un fragmento de su nombre o descripción.
     *
     * @param nombre O descripción a buscar.
     * @return Una lista de Herramienta que coinciden con la búsqueda, o una lista vacía si no se encuentran.
     */
    public List<Herramienta> buscarHerramientasPorNombre(String nombre) {
        List<Herramienta> herramientas = new ArrayList<>();
        String sql = "SELECT h.id_herramienta, h.nombre, h.marca, h.descripcion, h.estado, h.disponibilidad, h.qr_code_path, " +
                "h.asignado_a, e.nombres, e.apellidos " +
                "FROM Herramientas h LEFT JOIN Empleados e ON h.asignado_a = e.id_empleado " +
                "WHERE h.nombre LIKE ? OR h.descripcion LIKE ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, "%" + nombre + "%");
            pstmt.setString(2, "%" + nombre + "%");

            rs = pstmt.executeQuery();

            while (rs.next()) {
                Herramienta herramienta = new Herramienta();
                herramienta.setIdHerramienta(rs.getInt("id_herramienta"));
                herramienta.setNombre(rs.getString("nombre"));
                herramienta.setMarca(rs.getString("marca"));
                herramienta.setDescripcion(rs.getString("descripcion"));
                herramienta.setEstado(rs.getString("estado"));
                herramienta.setDisponibilidad(rs.getString("disponibilidad"));
                herramienta.setQrCodePath(rs.getString("qr_code_path"));

                // --- CORRECCIÓN similar aquí ---
                Integer asignadoAIdEmpleado = null;
                Object asignadoAObj = rs.getObject("asignado_a");
                if (asignadoAObj instanceof Long) {
                    asignadoAIdEmpleado = ((Long) asignadoAObj).intValue();
                } else if (asignadoAObj instanceof Integer) {
                    asignadoAIdEmpleado = (Integer) asignadoAObj;
                }
                herramienta.setAsignadoAIdEmpleado(asignadoAIdEmpleado);
                // --- FIN DE CORRECCIÓN ---

                if (asignadoAIdEmpleado != null) {
                    herramienta.setAsignadoANombreCompleto(rs.getString("nombres") + " " + rs.getString("apellidos"));
                } else {
                    herramienta.setAsignadoANombreCompleto("N/A");
                }

                herramientas.add(herramienta);
            }
        } catch (SQLException e) {
            System.err.println("Error de SQL al buscar herramientas por nombre: " + e.getMessage());
            e.printStackTrace();
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                DatabaseConnection.closeConnection(conn);
            } catch (SQLException e) {
                System.err.println("Error al cerrar recursos en buscarHerramientasPorNombre: " + e.getMessage());
                e.printStackTrace();
            }
        }
        return herramientas;
    }
    /**
     * Elimina una herramienta de la base de datos.
     * @param idHerramienta El ID de la herramienta a eliminar.
     * @return true si la herramienta fue eliminada exitosamente, false en caso contrario.
     */
    public boolean eliminarHerramienta(int idHerramienta) {
        String sql = "DELETE FROM Herramientas WHERE id_herramienta = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, idHerramienta);

            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar herramienta: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
    }
}