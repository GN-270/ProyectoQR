package com.fys.inventario.main;

import com.fys.inventario.model.Empleado;
import com.fys.inventario.ui.*; // Importa todas las clases UI

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MainApp extends JFrame { // MainApp ahora es la ventana de bienvenida

    private JButton btnAdminAccess;
    private JButton btnUserAccess;
    private JLabel welcomeLabel;

    public MainApp() {
        setTitle("Bienvenido al Sistema de Gestión de Inventario FYS");
        setSize(500, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); // Centrar en la pantalla

        initComponents();
        setupListeners();
    }

    private void initComponents() {
        setLayout(new BorderLayout(20, 20)); // Espaciado

        // Panel superior para el mensaje de bienvenida
        JPanel welcomePanel = new JPanel(new BorderLayout());
        welcomePanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 10, 20)); // Padding
        welcomeLabel = new JLabel("<html><h2 style='text-align: center;'>Bienvenido a la aplicación de Gestión de Inventario</h2><p style='text-align: center;'>Inicia sesión como:</p></html>", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Segoe UI", Font.PLAIN, 16));
        welcomePanel.add(welcomeLabel, BorderLayout.CENTER);
        add(welcomePanel, BorderLayout.NORTH);

        // Panel central para los botones de acceso
        JPanel buttonPanel = new JPanel(new GridLayout(2, 1, 15, 15)); // 2 filas, 1 columna, con espaciado
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(0, 50, 20, 50)); // Padding

        btnAdminAccess = new JButton("Acceder como Administrador");
        btnUserAccess = new JButton("Acceder como Usuario");

        btnAdminAccess.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnUserAccess.setFont(new Font("Segoe UI", Font.BOLD, 14));

        buttonPanel.add(btnAdminAccess);
        buttonPanel.add(btnUserAccess);
        add(buttonPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        btnAdminAccess.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Al hacer clic en Administrador, mostrar el diálogo de login normal
                LoginDialog loginDialog = new LoginDialog(MainApp.this);
                loginDialog.setVisible(true);

                // Aquí obtenemos el resultado del login solo después de que el diálogo se cierra
                if (loginDialog.getLoginResult() == LoginDialog.LoginResult.ADMIN_SUCCESS) {
                    Empleado loggedInAdmin = loginDialog.getLoggedInAdmin(); // Asumiendo que LoginDialog tiene este getter
                    if (loggedInAdmin != null) {
                        MainApp.this.dispose(); // Cierra la ventana de bienvenida
                        // Asegúrate de que AdminDashboardFrame tiene el constructor con Empleado
                        new AdminDashboardFrame(loggedInAdmin).setVisible(true); // Pasa el empleado logueado
                    }
                } else {
                    // Opcional: mostrar un mensaje si el login falló, aunque LoginDialog ya lo hace
                }
            }
        });

        btnUserAccess.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Al hacer clic en Usuario, mostrar el diálogo de login por QR (con cámara)
                UserLoginQrCameraDialog qrLoginDialog = new UserLoginQrCameraDialog(MainApp.this);
                qrLoginDialog.setVisible(true);

                // Aquí manejas el resultado del escaneo QR del empleado
                if (qrLoginDialog.getLoginResult() == UserLoginQrCameraDialog.LoginResult.SUCCESS) {
                    Empleado loggedInEmployee = qrLoginDialog.getLoggedInEmployee();
                    if (loggedInEmployee != null) {
                        MainApp.this.dispose(); // Cierra la ventana de bienvenida
                        // Asegúrate de que UserDashboardDialog tenga el constructor con JFrame parent
                        UserDashboardDialog userDashboard = new UserDashboardDialog(MainApp.this, loggedInEmployee); // Pasa this como parent
                        userDashboard.setVisible(true);
                    }
                } else {
                    JOptionPane.showMessageDialog(MainApp.this, "Inicio de sesión de usuario cancelado o fallido.", "Información", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new MainApp().setVisible(true); // Simplemente lanza la ventana de bienvenida
            }
        });
    }
}