package com.fys.inventario.ui;

import com.fys.inventario.dao.EmpleadoDAO;
import com.fys.inventario.model.Empleado;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class EmpleadoManagementDialog extends JDialog {

    private EmpleadoDAO empleadoDAO;
    private DefaultTableModel tableModel;
    private JTable empleadosTable;

    // Componentes para el formulario de entrada de datos
    private JTextField txtIdEmpleado; // Campo para mostrar el ID, no para entrada manual al agregar
    private JTextField txtDni;
    private JTextField txtNombres;
    private JTextField txtApellidos;
    // CAMBIO: Reemplazamos JTextField por JComboBox para 'Labor'
    private JComboBox<String> cbxLabor; // Ahora es un JComboBox
    private JLabel lblQrPath; // Para mostrar la ruta del QR

    private JButton btnAgregar;
    private JButton btnActualizar;
    private JButton btnEliminar;
    private JButton btnLimpiar; // Para limpiar los campos del formulario
    private JButton btnMostrarQr; // Para mostrar el QR generado

    // Array estático para definir las opciones de labor
    private static final String[] LABORES_DISPONIBLES = {
            "Operario",
            "Electricista",
            "Ayudante",
            "Soldador",
            "Mecánico",
            "Administrador" // Puedes ajustar o añadir más según tus necesidades
    };

    public EmpleadoManagementDialog(JFrame parent) {
        super(parent, "Gestión de Empleados", true); // true para que sea modal
        empleadoDAO = new EmpleadoDAO();
        setSize(800, 600);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        initComponents(); // Inicializar todos los componentes de la UI
        loadEmpleados();   // Cargar los empleados existentes al iniciar

        // Acción al seleccionar una fila de la tabla para cargar los datos en el formulario
        empleadosTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && empleadosTable.getSelectedRow() != -1) {
                int selectedRow = empleadosTable.getSelectedRow();
                txtIdEmpleado.setText(tableModel.getValueAt(selectedRow, 0).toString());
                txtDni.setText(tableModel.getValueAt(selectedRow, 1).toString());
                txtNombres.setText(tableModel.getValueAt(selectedRow, 2).toString());
                txtApellidos.setText(tableModel.getValueAt(selectedRow, 3).toString());

                // CAMBIO: Establecer el valor de la labor en el JComboBox
                Object laborValue = tableModel.getValueAt(selectedRow, 4);
                if (laborValue != null) {
                    cbxLabor.setSelectedItem(laborValue.toString());
                } else {
                    cbxLabor.setSelectedIndex(-1); // Desseleccionar si es null
                }

                // Asegurarse de que la ruta QR se muestre correctamente o N/A
                Object qrPathValue = tableModel.getValueAt(selectedRow, 5);
                lblQrPath.setText("Ruta QR: " + (qrPathValue != null ? qrPathValue.toString() : "N/A"));

                txtIdEmpleado.setEditable(false);
                btnAgregar.setEnabled(false);
                btnActualizar.setEnabled(true);
                btnEliminar.setEnabled(true);
            }
        });
    }

    private void initComponents() {
        // --- Panel Superior para el Formulario de Entrada ---
        JPanel inputPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        inputPanel.setBorder(BorderFactory.createTitledBorder("Datos del Empleado"));

        txtIdEmpleado = new JTextField(15);
        txtIdEmpleado.setEditable(false);
        txtDni = new JTextField(15);
        txtNombres = new JTextField(15);
        txtApellidos = new JTextField(15);
        // CAMBIO: Inicialización del JComboBox para Labor
        cbxLabor = new JComboBox<>(LABORES_DISPONIBLES); // Usa el array de labores disponibles
        lblQrPath = new JLabel("Ruta QR: N/A");

        inputPanel.add(new JLabel("ID Empleado:"));
        inputPanel.add(txtIdEmpleado);
        inputPanel.add(new JLabel("DNI:"));
        inputPanel.add(txtDni);
        inputPanel.add(new JLabel("Nombres:"));
        inputPanel.add(txtNombres);
        inputPanel.add(new JLabel("Apellidos:"));
        inputPanel.add(txtApellidos);
        inputPanel.add(new JLabel("Labor:"));
        inputPanel.add(cbxLabor); // Añadir el JComboBox en lugar del JTextField
        inputPanel.add(lblQrPath);

        // --- Panel de Botones del Formulario ---
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        btnAgregar = new JButton("Agregar");
        btnActualizar = new JButton("Actualizar");
        btnEliminar = new JButton("Eliminar");
        btnLimpiar = new JButton("Limpiar Campos");
        btnMostrarQr = new JButton("Mostrar QR");

        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);

        buttonPanel.add(btnAgregar);
        buttonPanel.add(btnActualizar);
        buttonPanel.add(btnEliminar);
        buttonPanel.add(btnLimpiar);
        buttonPanel.add(btnMostrarQr);

        JPanel formPanel = new JPanel(new BorderLayout());
        formPanel.add(inputPanel, BorderLayout.CENTER);
        formPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(formPanel, BorderLayout.NORTH);

        // --- Panel Central para la Tabla de Empleados ---
        String[] columnNames = {"ID Empleado", "DNI", "Nombres", "Apellidos", "Labor", "Ruta QR"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        empleadosTable = new JTable(tableModel);
        empleadosTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane scrollPane = new JScrollPane(empleadosTable);
        add(scrollPane, BorderLayout.CENTER);

        // --- Eventos de los botones de Acción ---
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                agregarEmpleado();
            }
        });

        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarEmpleado();
            }
        });

        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                eliminarEmpleado();
            }
        });

        btnLimpiar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                limpiarCampos();
            }
        });

        btnMostrarQr.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                mostrarQrEmpleado();
            }
        });
    }

    private void loadEmpleados() {
        tableModel.setRowCount(0);
        List<Empleado> empleados = empleadoDAO.obtenerTodosEmpleados();
        for (Empleado emp : empleados) {
            tableModel.addRow(new Object[]{
                    emp.getIdEmpleado(),
                    emp.getDni(),
                    emp.getNombres(),
                    emp.getApellidos(),
                    emp.getLabor(),
                    emp.getQrCodePath() != null ? emp.getQrCodePath() : "N/A"
            });
        }
    }

    private void agregarEmpleado() {
        // CAMBIO: El método validarCamposComunes ahora debe usar cbxLabor
        if (!validarCamposComunes()) return;

        String dni = txtDni.getText().trim();
        String nombres = txtNombres.getText().trim();
        String apellidos = txtApellidos.getText().trim();
        // CAMBIO: Obtener la labor directamente del JComboBox
        String labor = (String) cbxLabor.getSelectedItem();
        if (labor == null || labor.isEmpty()) { // Validar que se haya seleccionado una labor
            JOptionPane.showMessageDialog(this, "Debe seleccionar una labor para el empleado.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        Empleado nuevoEmpleado = new Empleado(0, dni, nombres, apellidos, labor, null);

        if (empleadoDAO.agregarEmpleado(nuevoEmpleado)) {
            JOptionPane.showMessageDialog(this, "Empleado agregado exitosamente. ID: " + nuevoEmpleado.getIdEmpleado(), "Éxito", JOptionPane.INFORMATION_MESSAGE);
            loadEmpleados();
            limpiarCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Error al agregar empleado. Posiblemente el DNI ya existe o hay un problema en la base de datos.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void actualizarEmpleado() {
        // CAMBIO: El método validarCamposComunes ahora debe usar cbxLabor
        if (!validarCamposComunes()) return;

        int idEmpleado;
        try {
            idEmpleado = Integer.parseInt(txtIdEmpleado.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID de empleado inválido. Debe ser un número entero.", "Error de Entrada", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String dni = txtDni.getText().trim();
        String nombres = txtNombres.getText().trim();
        String apellidos = txtApellidos.getText().trim();
        // CAMBIO: Obtener la labor directamente del JComboBox
        String labor = (String) cbxLabor.getSelectedItem();
        if (labor == null || labor.isEmpty()) { // Validar que se haya seleccionado una labor
            JOptionPane.showMessageDialog(this, "Debe seleccionar una labor para el empleado.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String qrPath = (lblQrPath.getText().startsWith("Ruta QR: ") && !lblQrPath.getText().equals("Ruta QR: N/A")) ?
                lblQrPath.getText().substring("Ruta QR: ".length()) : null;

        Empleado empleadoActualizar = new Empleado(idEmpleado, dni, nombres, apellidos, labor, qrPath);

        if (empleadoDAO.actualizarEmpleado(empleadoActualizar)) {
            JOptionPane.showMessageDialog(this, "Empleado actualizado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            loadEmpleados();
            limpiarCampos();
        } else {
            JOptionPane.showMessageDialog(this, "Error al actualizar empleado.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void eliminarEmpleado() {
        int idEmpleado;
        try {
            idEmpleado = Integer.parseInt(txtIdEmpleado.getText().trim());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "ID de empleado inválido. Debe ser un número entero.", "Error de Entrada", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (txtIdEmpleado.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Selecciona un empleado para eliminar.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Estás seguro de que quieres eliminar al empleado con ID: " + idEmpleado + "?",
                "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            if (empleadoDAO.eliminarEmpleado(idEmpleado)) {
                JOptionPane.showMessageDialog(this, "Empleado eliminado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                loadEmpleados();
                limpiarCampos();
            } else {
                JOptionPane.showMessageDialog(this, "Error al eliminar empleado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void limpiarCampos() {
        txtIdEmpleado.setText("");
        txtDni.setText("");
        txtNombres.setText("");
        txtApellidos.setText("");
        // CAMBIO: Limpiar el JComboBox seleccionando el primer elemento o un valor por defecto
        cbxLabor.setSelectedIndex(0); // Selecciona el primer elemento de la lista
        // Si quisieras que no haya nada seleccionado al limpiar, podrías usar:
        // cbxLabor.setSelectedItem(null);
        lblQrPath.setText("Ruta QR: N/A");

        txtIdEmpleado.setEditable(false); // Sigue siendo no editable, pero limpiado
        btnAgregar.setEnabled(true);
        btnActualizar.setEnabled(false);
        btnEliminar.setEnabled(false);
        empleadosTable.clearSelection();
    }

    /**
     * Valida los campos comunes (DNI, Nombres, Apellidos, Labor) que son obligatorios.
     * @return true si los campos obligatorios no están vacíos, false en caso contrario.
     */
    private boolean validarCamposComunes() {
        // CAMBIO: Validar el JComboBox en lugar del JTextField
        String selectedLabor = (String) cbxLabor.getSelectedItem();
        if (txtDni.getText().trim().isEmpty() ||
                txtNombres.getText().trim().isEmpty() ||
                txtApellidos.getText().trim().isEmpty() ||
                selectedLabor == null || selectedLabor.trim().isEmpty()) { // Validación para el JComboBox
            JOptionPane.showMessageDialog(this, "Todos los campos (DNI, Nombres, Apellidos, Labor) son obligatorios.", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void mostrarQrEmpleado() {
        String qrPath = (lblQrPath.getText().startsWith("Ruta QR: ") && !lblQrPath.getText().equals("Ruta QR: N/A")) ?
                lblQrPath.getText().substring("Ruta QR: ".length()) : null;

        if (qrPath == null || qrPath.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No hay código QR asociado a este empleado.", "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        try {
            ImageIcon qrIcon = new ImageIcon(qrPath);
            JLabel qrLabel = new JLabel(qrIcon);

            JDialog qrDialog = new JDialog(this, "Código QR del Empleado", true);
            qrDialog.setLayout(new BorderLayout());
            qrDialog.add(qrLabel, BorderLayout.CENTER);
            qrDialog.pack();
            qrDialog.setLocationRelativeTo(this);
            qrDialog.setVisible(true);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error al mostrar la imagen QR: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}