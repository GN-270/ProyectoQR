package com.fys.inventario.ui;

import com.fys.inventario.main.MainApp;
import com.fys.inventario.model.Empleado; // Asegúrate de que este import esté

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AdminDashboardFrame extends JFrame { // Es un JFrame, no JDialog

    private Empleado loggedInAdmin;
    private JLabel welcomeLabel;
    private JButton btnManageEmployees;
    private JButton btnManageTools;
    private JButton btnViewHistory;
    private JButton btnLogout;

    // Constructor que recibe el empleado administrador
    public AdminDashboardFrame(Empleado admin) {
        super("Sistema de Gestión de Inventario FYS - (Administrador)"); // Título de la ventana
        this.loggedInAdmin = admin;
        setSize(700, 500); // Tamaño más grande para el dashboard
        setLocationRelativeTo(null); // Centrar en la pantalla
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Cerrar toda la aplicación al cerrar esta ventana

        initComponents();
        setupListeners();
        updateWelcomeMessage();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10)); // Layout principal

        // Panel superior para el saludo
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        welcomeLabel = new JLabel("Cargando...", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Segoe UI", Font.BOLD, 22));
        topPanel.add(welcomeLabel);
        add(topPanel, BorderLayout.NORTH);

        // Panel central con botones de gestión
        JPanel buttonPanel = new JPanel(new GridLayout(4, 1, 20, 20)); // 4 filas para 4 botones, con espaciado
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(30, 100, 30, 100)); // Padding alrededor

        btnManageEmployees = new JButton("Gestionar Empleados");
        btnManageEmployees.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        buttonPanel.add(btnManageEmployees);

        btnManageTools = new JButton("Gestionar Herramientas");
        btnManageTools.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        buttonPanel.add(btnManageTools);

        btnViewHistory = new JButton("Ver Historial de Movimientos");
        btnViewHistory.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        buttonPanel.add(btnViewHistory);

        btnLogout = new JButton("Cerrar Sesión");
        btnLogout.setFont(new Font("Segoe UI", Font.PLAIN, 18));
        btnLogout.setBackground(new Color(220, 53, 69)); // Color rojo para cerrar sesión
        btnLogout.setForeground(Color.WHITE); // Texto blanco
        btnLogout.setFocusPainted(false); // Quitar el borde de foco
        buttonPanel.add(btnLogout);

        add(buttonPanel, BorderLayout.CENTER);
    }

    private void setupListeners() {
        btnManageEmployees.addActionListener(e -> {
            // Abrir el diálogo de gestión de empleados
            // Asumo que EmployeeManagementDialog es un JDialog y recibe un JFrame o JDialog como parent
            EmpleadoManagementDialog employeeManagementDialog = new EmpleadoManagementDialog(this);
            employeeManagementDialog.setVisible(true);
        });

        btnManageTools.addActionListener(e -> {
            // Abrir el diálogo de gestión de herramientas
            HerramientaManagementDialog toolManagementDialog = new HerramientaManagementDialog(this);
            toolManagementDialog.setVisible(true);
        });

        btnViewHistory.addActionListener(e -> {
            // Abrir el diálogo de historial de movimientos
            HistorialMovimientosDialog historialMovimientosDialog = new HistorialMovimientosDialog(this);
            historialMovimientosDialog.setVisible(true);
        });

        btnLogout.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this, "¿Está seguro de que desea cerrar sesión?", "Confirmar Cierre de Sesión", JOptionPane.YES_NO_OPTION);
            if (confirm == JOptionPane.YES_OPTION) {
                dispose(); // Cierra esta ventana del administrador
                // Volver a mostrar la ventana de bienvenida/login
                SwingUtilities.invokeLater(() -> new MainApp().setVisible(true));
            }
        });
    }

    private void updateWelcomeMessage() {
        if (loggedInAdmin != null) {
            welcomeLabel.setText("Bienvenido, Administrador " + loggedInAdmin.getNombres() + " " + loggedInAdmin.getApellidos() + ".");
        } else {
            welcomeLabel.setText("Bienvenido, Administrador."); // Fallback
        }
    }
}