package com.fys.inventario.model;

import java.time.LocalDateTime;



public class HistorialMovimiento {
    private int idMovimiento;
    private Integer idHerramienta;
    private String nombreHerramienta;
    private Integer idEmpleado;
    private String nombreEmpleado;
    private String tipoAccion; // <--- CAMBIO AQUÍ: de tipoMovimiento a tipoAccion
    private LocalDateTime fechaHora;
    private String comentarios; // <--- CAMBIO AQUÍ: de observaciones a comentarios

    // Constructor completo para recuperar de la DB
    public HistorialMovimiento(int idMovimiento, Integer idHerramienta, String nombreHerramienta,
                               Integer idEmpleado, String nombreEmpleado, String tipoAccion, // CAMBIO AQUÍ
                               LocalDateTime fechaHora, String comentarios) { // CAMBIO AQUÍ
        this.idMovimiento = idMovimiento;
        this.idHerramienta = idHerramienta;
        this.nombreHerramienta = nombreHerramienta;
        this.idEmpleado = idEmpleado;
        this.nombreEmpleado = nombreEmpleado;
        this.tipoAccion = tipoAccion; // CAMBIO AQUÍ
        this.fechaHora = fechaHora;
        this.comentarios = comentarios; // CAMBIO AQUÍ
    }

    // Constructor para un nuevo movimiento (ID se autogenera)
    public HistorialMovimiento(Integer idHerramienta, Integer idEmpleado, String tipoAccion, // CAMBIO AQUÍ
                               LocalDateTime fechaHora, String comentarios) { // CAMBIO AQUÍ
        this.idHerramienta = idHerramienta;
        this.idEmpleado = idEmpleado;
        this.tipoAccion = tipoAccion; // CAMBIO AQUÍ
        this.fechaHora = fechaHora;
        this.comentarios = comentarios; // CAMBIO AQUÍ
    }



    // Constructor vacío
    public HistorialMovimiento() {}

    // --- Getters y Setters ---

    public int getIdMovimiento() {
        return idMovimiento;
    }

    public void setIdMovimiento(int idMovimiento) {
        this.idMovimiento = idMovimiento;
    }

    public Integer getIdHerramienta() { // Retorna Integer
        return idHerramienta;
    }

    public void setIdHerramienta(Integer idHerramienta) { // Recibe Integer
        this.idHerramienta = idHerramienta;
    }

    public String getNombreHerramienta() {
        return nombreHerramienta;
    }

    public void setNombreHerramienta(String nombreHerramienta) {
        this.nombreHerramienta = nombreHerramienta;
    }

    public Integer getIdEmpleado() { // Retorna Integer
        return idEmpleado;
    }

    public void setIdEmpleado(Integer idEmpleado) { // Recibe Integer
        this.idEmpleado = idEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public String getTipoAccion() { // <--- CAMBIO AQUÍ
        return tipoAccion;
    }

    public void setTipoAccion(String tipoAccion) { // <--- CAMBIO AQUÍ
        this.tipoAccion = tipoAccion;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getComentarios() { // <--- CAMBIO AQUÍ
        return comentarios;
    }

    public void setComentarios(String comentarios) { // <--- CAMBIO AQUÍ
        this.comentarios = comentarios;
    }

    @Override
    public String toString() {
        return "HistorialMovimiento{" +
                "idMovimiento=" + idMovimiento +
                ", idHerramienta=" + idHerramienta +
                ", nombreHerramienta='" + nombreHerramienta + '\'' +
                ", idEmpleado=" + idEmpleado +
                ", nombreEmpleado='" + nombreEmpleado + '\'' +
                ", tipoAccion='" + tipoAccion + '\'' + // CAMBIO AQUÍ
                ", fechaHora=" + fechaHora +
                ", comentarios='" + comentarios + '\'' + // CAMBIO AQUÍ
                '}';
    }
}