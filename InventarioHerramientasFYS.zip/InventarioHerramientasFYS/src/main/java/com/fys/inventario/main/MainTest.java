package com.fys.inventario.main;

import com.fys.inventario.dao.EmpleadoDAO;
import com.fys.inventario.model.Empleado;

import java.util.List;
import java.util.Scanner; // Para entrada de usuario en la consola (opcional, para interacciones)

public class MainTest {

    public static void main(String[] args) {
        EmpleadoDAO empleadoDAO = new EmpleadoDAO();
        Scanner scanner = new Scanner(System.in); // Para leer entrada del usuario

        System.out.println("--- PRUEBA DE EMPLEADODAO ---");

        // --- 1. AGREGAR UN EMPLEADO ---
        System.out.println("\n--- Agregando un nuevo empleado ---");
        // Asegúrate de que el ID sea único y tenga 8 dígitos (o el formato que maneje tu DB si es INT)
        // Si tu DB genera el ID automáticamente, aquí no lo establezcas.
        // Si lo manejas tú, asegúrate de que sea un int válido.
        int nuevoIdEmpleado = 3; // Ejemplo, cambia si ya existe o si tu DB es autoincremental
        Empleado nuevoEmpleado = new Empleado(nuevoIdEmpleado, "00000003C", "Carlos", "Ramirez", "Ayudante", null); // QR path null por ahora

        if (empleadoDAO.agregarEmpleado(nuevoEmpleado)) {
            System.out.println("Empleado '" + nuevoEmpleado.getNombres() + " " + nuevoEmpleado.getApellidos() + "' agregado exitosamente con ID: " + nuevoEmpleado.getIdEmpleado());
        } else {
            System.out.println("Fallo al agregar el empleado. (Podría ser por ID/DNI duplicado o error de conexión)");
        }

        // --- 2. OBTENER TODOS LOS EMPLEADOS ---
        System.out.println("\n--- Listado de todos los empleados ---");
        List<Empleado> empleados = empleadoDAO.obtenerTodosEmpleados();
        if (empleados.isEmpty()) {
            System.out.println("No hay empleados en la base de datos.");
        } else {
            for (Empleado emp : empleados) {
                System.out.println("ID: " + emp.getIdEmpleado() + ", DNI: " + emp.getDni() + ", Nombre: " + emp.getNombres() + " " + emp.getApellidos() + ", Labor: " + emp.getLabor() + ", QR: " + (emp.getQrCodePath() != null ? emp.getQrCodePath() : "N/A"));
            }
        }

        // --- 3. OBTENER UN EMPLEADO POR ID ---
        System.out.println("\n--- Buscando un empleado por ID ---");
        System.out.print("Introduce el ID del empleado a buscar (ej: 1): ");
        int idBuscar = 0;
        try {
            idBuscar = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.err.println("ID de empleado inválido. Debe ser un número entero.");
            scanner.close();
            return;
        }

        Empleado empBuscadoId = empleadoDAO.obtenerEmpleadoPorId(idBuscar); // CAMBIO: Pasar int
        if (empBuscadoId != null) {
            System.out.println("Empleado encontrado por ID: " + empBuscadoId.getNombres() + " " + empBuscadoId.getApellidos() + ", Labor: " + empBuscadoId.getLabor());
        } else {
            System.out.println("Empleado con ID " + idBuscar + " no encontrado.");
        }

        // --- 4. ACTUALIZAR UN EMPLEADO ---
        System.out.println("\n--- Actualizando un empleado existente ---");
        System.out.print("Introduce el ID del empleado a actualizar (ej: 1 para Juan Pérez): ");
        int idActualizar = 0;
        try {
            idActualizar = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.err.println("ID de empleado inválido. Debe ser un número entero.");
            scanner.close();
            return;
        }

        // Primero lo obtenemos para asegurarnos de que exista y tener sus datos actuales
        Empleado empleadoAActualizar = empleadoDAO.obtenerEmpleadoPorId(idActualizar); // CAMBIO: Pasar int
        if (empleadoAActualizar != null) {
            empleadoAActualizar.setLabor("Supervisor"); // Cambiamos su labor
            empleadoAActualizar.setQrCodePath("/qrcodes/empleados/" + empleadoAActualizar.getIdEmpleado() + ".png"); // Simular ruta QR con ID actual

            if (empleadoDAO.actualizarEmpleado(empleadoAActualizar)) {
                System.out.println("Empleado ID " + empleadoAActualizar.getIdEmpleado() + " actualizado exitosamente a Labor: " + empleadoAActualizar.getLabor());
            } else {
                System.out.println("Fallo al actualizar el empleado ID " + empleadoAActualizar.getIdEmpleado() + ".");
            }
        } else {
            System.out.println("El empleado con ID " + idActualizar + " no existe para actualizar.");
        }

        // Volvemos a listar para ver el cambio
        System.out.println("\n--- Listado de empleados después de actualizar ---");
        empleados = empleadoDAO.obtenerTodosEmpleados();
        if (empleados.isEmpty()) {
            System.out.println("No hay empleados en la base de datos.");
        } else {
            for (Empleado emp : empleados) {
                System.out.println("ID: " + emp.getIdEmpleado() + ", DNI: " + emp.getDni() + ", Nombre: " + emp.getNombres() + " " + emp.getApellidos() + ", Labor: " + emp.getLabor() + ", QR: " + (emp.getQrCodePath() != null ? emp.getQrCodePath() : "N/A"));
            }
        }

        // --- 5. ELIMINAR UN EMPLEADO (¡Ten cuidado con este paso, puede causar errores si tiene historial!) ---
        System.out.println("\n--- Intentando eliminar un empleado ---");
        System.out.print("Introduce el ID del empleado a eliminar (ej: " + nuevoIdEmpleado + " si fue agregado): ");
        int idEliminar = 0;
        try {
            idEliminar = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.err.println("ID de empleado inválido. Debe ser un número entero.");
            scanner.close();
            return;
        }

        System.out.print("¿Deseas intentar eliminar el empleado con ID " + idEliminar + "? (s/n): ");
        String confirmacion = scanner.nextLine();
        if (confirmacion.equalsIgnoreCase("s")) {
            if (empleadoDAO.eliminarEmpleado(idEliminar)) { // CAMBIO: Pasar int
                System.out.println("Empleado con ID " + idEliminar + " eliminado exitosamente.");
            } else {
                System.out.println("Fallo al eliminar el empleado con ID " + idEliminar + ". (Podría tener dependencias en HistorialMovimientos)");
            }
        } else {
            System.out.println("Eliminación cancelada.");
        }

        System.out.println("\n--- Listado final de todos los empleados ---");
        empleados = empleadoDAO.obtenerTodosEmpleados();
        if (empleados.isEmpty()) {
            System.out.println("No hay empleados en la base de datos.");
        } else {
            for (Empleado emp : empleados) {
                System.out.println("ID: " + emp.getIdEmpleado() + ", DNI: " + emp.getDni() + ", Nombre: " + emp.getNombres() + " " + emp.getApellidos() + ", Labor: " + emp.getLabor() + ", QR: " + (emp.getQrCodePath() != null ? emp.getQrCodePath() : "N/A"));
            }
        }

        scanner.close(); // Cerrar el scanner
        System.out.println("\n--- FIN DE LA PRUEBA ---");
    }
}