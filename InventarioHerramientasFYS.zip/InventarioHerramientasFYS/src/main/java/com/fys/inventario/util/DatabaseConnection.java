package com.fys.inventario.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // La IP pública de tu instancia de Cloud SQL según image_e07ae2.png es 34.176.195.209
    // La base de datos es 'inventario_fys' según el dump SQL
    private static final String URL = "jdbc:mysql://34.176.195.209:3306/inventario_fys";
    private static final String USER = "root";   // <<-- ¡REEMPLAZA CON TU USUARIO REAL DE MYSQL!
    private static final String PASSWORD = "270F-652a"; // <<-- ¡REEMPLAZA CON TU CONTRASEÑA REAL DE MYSQL!

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                System.err.println("Error al cerrar la conexión: " + e.getMessage());
                e.printStackTrace();
            }
        }
    }
}