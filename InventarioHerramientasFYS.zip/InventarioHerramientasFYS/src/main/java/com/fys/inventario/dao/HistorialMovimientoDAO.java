package com.fys.inventario.dao;

import com.fys.inventario.model.HistorialMovimiento;
import com.fys.inventario.util.DatabaseConnection;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class HistorialMovimientoDAO {

    public boolean agregarMovimiento(HistorialMovimiento movimiento) {
        String sql = "INSERT INTO HistorialMovimientos (id_herramienta, id_empleado, tipo_accion, fecha_hora, comentarios) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        boolean success = false;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            if (movimiento.getIdHerramienta() != null) {
                pstmt.setInt(1, movimiento.getIdHerramienta());
            } else {
                pstmt.setNull(1, Types.INTEGER);
            }

            if (movimiento.getIdEmpleado() != null) {
                pstmt.setInt(2, movimiento.getIdEmpleado());
            } else {
                pstmt.setNull(2, Types.INTEGER);
            }

            pstmt.setString(3, movimiento.getTipoAccion());
            pstmt.setTimestamp(4, Timestamp.valueOf(movimiento.getFechaHora()));
            pstmt.setString(5, movimiento.getComentarios());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                success = true;
                rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    // Asumiendo que id_movimiento también puede ser BIGINT, aunque suele ser INT
                    // Si es INT en DB, rs.getInt(1) está bien. Si es BIGINT, mejor rs.getLong(1).intValue();
                    movimiento.setIdMovimiento(rs.getInt(1));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al agregar movimiento al historial: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (pstmt != null) {
                try {
                    pstmt.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return success;
    }

    public List<HistorialMovimiento> obtenerTodosMovimientos() {
        List<HistorialMovimiento> movimientos = new ArrayList<>();
        String sql = "SELECT hm.id_movimiento, hm.id_herramienta, h.nombre AS nombre_herramienta, " +
                "hm.id_empleado, e.nombres AS nombre_empleado_nombres, e.apellidos AS nombre_empleado_apellidos, " +
                "hm.tipo_accion, hm.fecha_hora, hm.comentarios " +
                "FROM HistorialMovimientos hm " +
                "LEFT JOIN Herramientas h ON hm.id_herramienta = h.id_herramienta " +
                "LEFT JOIN Empleados e ON hm.id_empleado = e.id_empleado " +
                "ORDER BY hm.fecha_hora DESC";

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                // --- INICIO DE CORRECCIÓN (línea 119 original) ---
                Integer idHerramienta = null;
                Object idHerramientaObj = rs.getObject("id_herramienta");
                if (idHerramientaObj instanceof Long) {
                    idHerramienta = ((Long) idHerramientaObj).intValue();
                } else if (idHerramientaObj instanceof Integer) {
                    idHerramienta = (Integer) idHerramientaObj;
                }
                // --- FIN DE CORRECCIÓN ---

                String nombreHerramienta = rs.getString("nombre_herramienta");
                if (idHerramienta != null && nombreHerramienta == null) {
                    nombreHerramienta = "ID " + idHerramienta + " (Herramienta Eliminada)";
                } else if (idHerramienta == null && nombreHerramienta == null) {
                    nombreHerramienta = "N/A";
                }

                // --- INICIO DE CORRECCIÓN (línea similar para id_empleado) ---
                Integer idEmpleado = null;
                Object idEmpleadoObj = rs.getObject("id_empleado");
                if (idEmpleadoObj instanceof Long) {
                    idEmpleado = ((Long) idEmpleadoObj).intValue();
                } else if (idEmpleadoObj instanceof Integer) {
                    idEmpleado = (Integer) idEmpleadoObj;
                }
                // --- FIN DE CORRECCIÓN ---

                String nombreEmpleadoNombres = rs.getString("nombre_empleado_nombres");
                String nombreEmpleadoApellidos = rs.getString("nombre_empleado_apellidos");
                String nombreEmpleadoCompleto = "N/A";

                if (idEmpleado != null) {
                    if (nombreEmpleadoNombres != null && nombreEmpleadoApellidos != null) {
                        nombreEmpleadoCompleto = nombreEmpleadoNombres + " " + nombreEmpleadoApellidos;
                    } else if (nombreEmpleadoNombres != null) {
                        nombreEmpleadoCompleto = nombreEmpleadoNombres;
                    } else if (nombreEmpleadoApellidos != null) {
                        nombreEmpleadoCompleto = nombreEmpleadoApellidos;
                    } else {
                        nombreEmpleadoCompleto = "ID " + idEmpleado + " (Empleado Eliminado)";
                    }
                }

                movimientos.add(new HistorialMovimiento(
                        rs.getInt("id_movimiento"),
                        idHerramienta,
                        nombreHerramienta,
                        idEmpleado,
                        nombreEmpleadoCompleto,
                        rs.getString("tipo_accion"),
                        rs.getTimestamp("fecha_hora").toLocalDateTime(),
                        rs.getString("comentarios")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener todos los movimientos del historial: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) { try { rs.close(); } catch (SQLException e) { e.printStackTrace(); } }
            if (pstmt != null) { try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); } }
            DatabaseConnection.closeConnection(conn);
        }
        return movimientos;
    }

    public List<HistorialMovimiento> buscarMovimientos(Integer idEmpleado, Integer idHerramienta, String tipoAccion) {
        List<HistorialMovimiento> movimientos = new ArrayList<>();
        StringBuilder sqlBuilder = new StringBuilder("SELECT hm.id_movimiento, hm.id_herramienta, h.nombre AS nombre_herramienta, " +
                "hm.id_empleado, e.nombres AS nombre_empleado_nombres, e.apellidos AS nombre_empleado_apellidos, " +
                "hm.tipo_accion, hm.fecha_hora, hm.comentarios " +
                "FROM HistorialMovimientos hm " +
                "LEFT JOIN Herramientas h ON hm.id_herramienta = h.id_herramienta " +
                "LEFT JOIN Empleados e ON hm.id_empleado = e.id_empleado " +
                "WHERE 1=1");

        List<Object> params = new ArrayList<>();
        if (idEmpleado != null) {
            sqlBuilder.append(" AND hm.id_empleado = ?");
            params.add(idEmpleado);
        }
        if (idHerramienta != null) {
            sqlBuilder.append(" AND hm.id_herramienta = ?");
            params.add(idHerramienta);
        }
        if (tipoAccion != null && !tipoAccion.isEmpty()) {
            sqlBuilder.append(" AND hm.tipo_accion = ?");
            params.add(tipoAccion);
        }

        sqlBuilder.append(" ORDER BY hm.fecha_hora DESC");

        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sqlBuilder.toString());

            for (int i = 0; i < params.size(); i++) {
                pstmt.setObject(i + 1, params.get(i));
            }

            rs = pstmt.executeQuery();

            while (rs.next()) {
                // --- CORRECCIÓN similar aquí para buscarMovimientos ---
                Integer currentIdHerramienta = null;
                Object currentIdHerramientaObj = rs.getObject("id_herramienta");
                if (currentIdHerramientaObj instanceof Long) {
                    currentIdHerramienta = ((Long) currentIdHerramientaObj).intValue();
                } else if (currentIdHerramientaObj instanceof Integer) {
                    currentIdHerramienta = (Integer) currentIdHerramientaObj;
                }

                String nombreHerramienta = rs.getString("nombre_herramienta");
                if (currentIdHerramienta != null && nombreHerramienta == null) {
                    nombreHerramienta = "ID " + currentIdHerramienta + " (Herramienta Eliminada)";
                } else if (currentIdHerramienta == null && nombreHerramienta == null) {
                    nombreHerramienta = "N/A";
                }

                Integer currentIdEmpleado = null;
                Object currentIdEmpleadoObj = rs.getObject("id_empleado");
                if (currentIdEmpleadoObj instanceof Long) {
                    currentIdEmpleado = ((Long) currentIdEmpleadoObj).intValue();
                } else if (currentIdEmpleadoObj instanceof Integer) {
                    currentIdEmpleado = (Integer) currentIdEmpleadoObj;
                }
                // --- FIN DE CORRECCIÓN ---

                String nombreEmpleadoNombres = rs.getString("nombre_empleado_nombres");
                String nombreEmpleadoApellidos = rs.getString("nombre_empleado_apellidos");
                String nombreEmpleadoCompleto = "N/A";

                if (currentIdEmpleado != null) {
                    if (nombreEmpleadoNombres != null && nombreEmpleadoApellidos != null) {
                        nombreEmpleadoCompleto = nombreEmpleadoNombres + " " + nombreEmpleadoApellidos;
                    } else if (nombreEmpleadoNombres != null) {
                        nombreEmpleadoCompleto = nombreEmpleadoNombres;
                    } else if (nombreEmpleadoApellidos != null) {
                        nombreEmpleadoCompleto = nombreEmpleadoApellidos;
                    } else {
                        nombreEmpleadoCompleto = "ID " + currentIdEmpleado + " (Empleado Eliminado)";
                    }
                }

                movimientos.add(new HistorialMovimiento(
                        rs.getInt("id_movimiento"),
                        currentIdHerramienta,
                        nombreHerramienta,
                        currentIdEmpleado,
                        nombreEmpleadoCompleto,
                        rs.getString("tipo_accion"),
                        rs.getTimestamp("fecha_hora").toLocalDateTime(),
                        rs.getString("comentarios")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error al buscar movimientos en el historial: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) { try { rs.close(); } catch (SQLException e) { e.printStackTrace(); } }
            if (pstmt != null) { try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); } }
            DatabaseConnection.closeConnection(conn);
        }
        return movimientos;
    }
}