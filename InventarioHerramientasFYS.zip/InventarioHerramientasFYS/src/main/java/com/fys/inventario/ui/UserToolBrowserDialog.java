package com.fys.inventario.ui;

import com.fys.inventario.dao.HerramientaDAO;
import com.fys.inventario.dao.HistorialMovimientoDAO;
import com.fys.inventario.model.Herramienta;
import com.fys.inventario.model.Empleado; // Importar Empleado
import com.fys.inventario.model.HistorialMovimiento;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDateTime;
import java.util.List;

public class UserToolBrowserDialog extends JDialog {

    private HerramientaDAO herramientaDAO;
    private HistorialMovimientoDAO historialDAO; // Para registrar préstamos
    private DefaultTableModel tableModel;
    private JTable toolTable;
    private JButton btnRequestTool;

    private Empleado loggedInEmployee; // Para saber quién está solicitando

    public UserToolBrowserDialog(java.awt.Dialog parent, Empleado employee) { // CAMBIO AQUÍ: de JFrame a java.awt.Dialog
        super(parent, "Inventario de Herramientas Disponibles", true);
        this.loggedInEmployee = employee;
        herramientaDAO = new HerramientaDAO();
        historialDAO = new HistorialMovimientoDAO();

        setSize(800, 600);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        initComponents();
        loadTools();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // Panel para el título
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        JLabel titleLabel = new JLabel("Herramientas Disponibles para Solicitud");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 20));
        topPanel.add(titleLabel);
        add(topPanel, BorderLayout.NORTH);

        // Tabla de herramientas
        String[] columnNames = {"ID", "Nombre", "Descripción", "Marca", "Estado Físico", "Disponibilidad"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Las celdas no son editables para el usuario
            }
        };
        toolTable = new JTable(tableModel);
        toolTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION); // Solo se puede seleccionar una herramienta a la vez
        JScrollPane scrollPane = new JScrollPane(toolTable);
        add(scrollPane, BorderLayout.CENTER);

        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        btnRequestTool = new JButton("Solicitar Herramienta Seleccionada");
        btnRequestTool.setFont(new Font("Segoe UI", Font.BOLD, 14));
        buttonPanel.add(btnRequestTool);
        add(buttonPanel, BorderLayout.SOUTH);

        setupListeners();
    }

    private void setupListeners() {
        btnRequestTool.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                requestSelectedTool();
            }
        });
    }

    private void loadTools() {
        tableModel.setRowCount(0); // Limpiar la tabla
        List<Herramienta> herramientas = herramientaDAO.obtenerTodasHerramientas(); // Obtener todas las herramientas

        for (Herramienta herramienta : herramientas) {
            // Mostrar solo las herramientas disponibles para solicitar
            if ("Libre".equalsIgnoreCase(herramienta.getDisponibilidad())) {
                tableModel.addRow(new Object[]{
                        herramienta.getIdHerramienta(),
                        herramienta.getNombre(),
                        herramienta.getDescripcion(),
                        herramienta.getMarca(),
                        herramienta.getEstado(),
                        herramienta.getDisponibilidad()
                });
            }
        }
    }

    private void requestSelectedTool() {
        int selectedRow = toolTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Por favor, seleccione una herramienta de la tabla para solicitar.", "Ninguna Herramienta Seleccionada", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Obtener los datos de la herramienta seleccionada
        int idHerramienta = (int) tableModel.getValueAt(selectedRow, 0);
        String nombreHerramienta = (String) tableModel.getValueAt(selectedRow, 1);

        // Confirmación de la solicitud
        int confirm = JOptionPane.showConfirmDialog(this,
                "¿Está seguro de que desea solicitar la herramienta: " + nombreHerramienta + "?",
                "Confirmar Solicitud", JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            // Generar un resumen del material (para el administrador)
            String resumen = "Solicitud de Herramienta:\n" +
                    "Empleado: " + loggedInEmployee.getNombres() + " " + loggedInEmployee.getApellidos() + " (ID: " + loggedInEmployee.getIdEmpleado() + ", DNI: " + loggedInEmployee.getDni() + ")\n" +
                    "Herramienta: " + nombreHerramienta + " (ID: " + idHerramienta + ")\n" +
                    "Fecha y Hora: " + LocalDateTime.now().format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));

            JOptionPane.showMessageDialog(this, resumen, "Resumen de Solicitud", JOptionPane.INFORMATION_MESSAGE);

            // Actualizar el estado de la herramienta en la base de datos
            // La disponibilidad cambia a "Prestada", y se asigna al empleado logueado
            // Tu HerramientaDAO necesita un método para esto.
            // Por ejemplo: actualizarEstadoYAsignacion(idHerramienta, "Prestada", loggedInEmployee.getIdEmpleado())
            if (herramientaDAO.actualizarDisponibilidad(idHerramienta, "Prestada", loggedInEmployee.getIdEmpleado())) {
                // Registrar el movimiento en el historial
                HistorialMovimiento historial = new HistorialMovimiento(
                        0, // ID se autogenera
                        idHerramienta,
                        nombreHerramienta,
                        loggedInEmployee.getIdEmpleado(),
                        loggedInEmployee.getNombres() + " " + loggedInEmployee.getApellidos(),
                        "Prestacion",
                        LocalDateTime.now(),
                        "Préstamo a " + loggedInEmployee.getNombres() + " " + loggedInEmployee.getApellidos()
                );

                if (historialDAO.agregarMovimiento(historial)) {
                    JOptionPane.showMessageDialog(this, "Herramienta '" + nombreHerramienta + "' solicitada y registrada en el historial exitosamente.", "Solicitud Exitosa", JOptionPane.INFORMATION_MESSAGE);
                    loadTools(); // Recargar la tabla para reflejar los cambios (la herramienta ya no debería aparecer como "Libre")
                } else {
                    JOptionPane.showMessageDialog(this, "Error al registrar el movimiento en el historial.", "Error", JOptionPane.ERROR_MESSAGE);
                    // Opcional: Si el registro en historial falla, podrías revertir el estado de la herramienta
                    herramientaDAO.actualizarDisponibilidad(idHerramienta, "Libre", null); // Desasignar y liberar
                }
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar el estado de la herramienta en el inventario.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}