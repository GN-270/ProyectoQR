package com.fys.inventario.util;

import com.google.zxing.*;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.client.j2se.MatrixToImageWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

// IMPORTS NECESARIOS PARA LA LECTURA DE QR
import com.google.zxing.client.j2se.BufferedImageLuminanceSource; // Para convertir BufferedImage a LuminanceSource
import com.google.zxing.common.HybridBinarizer; // Binarizador
import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File; // Para manejar archivos
// FIN DE IMPORTS PARA LECTURA

import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.EnumMap;
import java.util.Map;

/**
 * Utilidad para generar y guardar códigos QR.
 */
public class QrCodeUtil {

    /**
     * Enum para definir los tipos de QR (para organización de directorios).
     */
    public enum QrType {
        HERRAMIENTA("qrcodes/herramientas"),
        EMPLEADO("qrcodes/empleados"),
        DEFAULT("qrcodes/general"); // Un tipo por defecto si es necesario

        private final String directory;

        QrType(String directory) {
            this.directory = directory;
        }

        public String getDirectory() {
            return directory;
        }
    }

    /**
     * Genera un código QR y lo guarda como una imagen PNG.
     *
     * @param content El contenido (texto) a codificar en el QR.
     * @param fileNamePrefix El prefijo para el nombre del archivo de imagen (ej. "herramienta_123").
     * @param qrType El tipo de QR, que determina el subdirectorio donde se guardará.
     * @return La ruta absoluta del archivo PNG del código QR generado, o null si falla.
     * @throws IOException Si ocurre un error de E/S al escribir el archivo.
     * @throws WriterException Si ocurre un error al generar el código QR.
     */
    public static String generateAndSaveQrCode(String content, String fileNamePrefix, QrType qrType)
            throws IOException, WriterException { // Declara las excepciones
        int width = 300; // Ancho de la imagen del QR
        int height = 300; // Alto de la imagen del QR
        String format = "PNG"; // Formato de la imagen

        // Configuración de las pistas de codificación
        Map<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
        hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
        hints.put(EncodeHintType.MARGIN, 1); // Margen alrededor del QR
        hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.H); // Nivel de corrección de error alto

        try {
            QRCodeWriter qrCodeWriter = new QRCodeWriter();
            BitMatrix bitMatrix = qrCodeWriter.encode(content, BarcodeFormat.QR_CODE, width, height, hints);

            // Crear el directorio si no existe
            Path directoryPath = FileSystems.getDefault().getPath(qrType.getDirectory());
            if (!java.nio.file.Files.exists(directoryPath)) {
                java.nio.file.Files.createDirectories(directoryPath);
            }

            // Nombre completo del archivo
            String filePath = qrType.getDirectory() + "/" + fileNamePrefix + "." + format.toLowerCase();
            Path path = FileSystems.getDefault().getPath(filePath);

            MatrixToImageWriter.writeToPath(bitMatrix, format, path);
            System.out.println("Código QR generado exitosamente en: " + path.toAbsolutePath());
            return path.toAbsolutePath().toString(); // Devuelve la ruta absoluta como String
        } catch (WriterException | IOException e) {
            // No imprimir aquí, dejar que el llamador lo maneje o relanzar
            throw e; // Relanzar las excepciones para que el HerramientaDAO las capture
        }
    }

    /**
     * Lee un código QR de una imagen de archivo.
     *
     * @param qrImageFile El archivo de imagen que contiene el código QR.
     * @return El contenido (texto) del código QR.
     * @throws IOException Si ocurre un error de E/S al leer la imagen.
     * @throws NotFoundException Si no se encuentra un código QR en la imagen.
     */
    public static String readQrCode(File qrImageFile) throws IOException, NotFoundException {
        BufferedImage image = ImageIO.read(qrImageFile);
        if (image == null) {
            throw new IOException("No se pudo leer la imagen del archivo: " + qrImageFile.getName());
        }

        LuminanceSource source = new BufferedImageLuminanceSource(image);
        BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));

        // MultiFormatReader puede leer varios tipos de códigos de barras, incluyendo QR.
        // Es más flexible que QRCodeReader directo.
        Result result = new MultiFormatReader().decode(bitmap);

        return result.getText();
    }
}