package com.fys.inventario.ui;

import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.github.sarxos.webcam.WebcamResolution;
import com.google.zxing.BinaryBitmap;
import com.google.zxing.MultiFormatReader;
import com.google.zxing.NotFoundException;
import com.google.zxing.Result;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.google.zxing.common.HybridBinarizer;
import com.fys.inventario.model.Empleado;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public class ToolReturnQrScanDialog extends JDialog {

    private Empleado loggedInEmployee;
    private Webcam webcam;
    private WebcamPanel webcamPanel;
    private JTextArea resultTextArea;
    private ScheduledExecutorService executorService;
    private AtomicBoolean isReading = new AtomicBoolean(false); // Para controlar el estado de lectura del hilo

    public ToolReturnQrScanDialog(JDialog parent, Empleado loggedInEmployee) {
        super(parent, "Escanear QR para Devolución de Herramienta", true);
        this.loggedInEmployee = loggedInEmployee;

        setSize(600, 500);
        setLocationRelativeTo(parent);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE); // Importante para manejar el cierre de la cámara

        // 1. Intentar inicializar la cámara ANTES de crear componentes
        webcam = Webcam.getDefault();
        if (webcam == null) {
            JOptionPane.showMessageDialog(this, "No se detectó ninguna cámara web. Asegúrese de que una cámara esté conectada y no esté en uso por otra aplicación.", "Error de Cámara", JOptionPane.ERROR_MESSAGE);
            dispose(); // Cerrar el diálogo si no hay cámara
            return;
        }

        // 2. Configurar la resolución y abrir la cámara
        webcam.setViewSize(WebcamResolution.VGA.getSize());
        webcam.open(); // Abrir la cámara lo antes posible para el panel

        initComponents();
        startScanning(); // Iniciar el hilo de escaneo
    }

    private void initComponents() {
        setLayout(new BorderLayout());
        JPanel mainPanel = new JPanel(new BorderLayout());

        // Asegúrate de que 'webcam' no es null aquí. La lógica en el constructor ya lo maneja.
        webcamPanel = new WebcamPanel(webcam);
        webcamPanel.setFPSDisplayed(true);
        webcamPanel.setDisplayDebugInfo(false); // No mostrar debug info en producción
        webcamPanel.setMirrored(true); // Reflejar para una experiencia más intuitiva

        mainPanel.add(webcamPanel, BorderLayout.CENTER);

        resultTextArea = new JTextArea("Esperando escaneo de código QR de herramienta...");
        resultTextArea.setEditable(false);
        resultTextArea.setLineWrap(true);
        resultTextArea.setWrapStyleWord(true);
        resultTextArea.setFont(new Font("Monospaced", Font.BOLD, 16));
        resultTextArea.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.add(new JScrollPane(resultTextArea), BorderLayout.SOUTH);

        add(mainPanel, BorderLayout.CENTER);
    }

    private void startScanning() {
        executorService = Executors.newSingleThreadScheduledExecutor();
        // Escanear cada 100 milisegundos
        executorService.scheduleAtFixedRate(() -> {
            // Solo procesar si el AtomicBoolean indica que la lectura está activa
            if (isReading.get() && webcam != null && webcam.isOpen()) {
                BufferedImage image = webcam.getImage();
                if (image != null) {
                    BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(
                            new BufferedImageLuminanceSource(image)));
                    try {
                        Result result = new MultiFormatReader().decode(bitmap);
                        String qrContent = result.getText();
                        System.out.println("QR Escaneado: " + qrContent);

                        // Detener temporalmente el escaneo para procesar el QR
                        isReading.set(false); // Evita que se escaneen múltiples veces el mismo QR

                        SwingUtilities.invokeLater(() -> {
                            resultTextArea.setText("QR de herramienta detectado: " + qrContent);
                            try {
                                int toolId = Integer.parseInt(qrContent.trim());
                                // Abrir el diálogo de detalles de devolución.
                                // Se pasa 'this' como parent.
                                ToolReturnDetailsDialog detailsDialog = new ToolReturnDetailsDialog(this, toolId, loggedInEmployee);
                                detailsDialog.setVisible(true); // Esto bloqueará el hilo hasta que detailsDialog se cierre

                                // Una vez que detailsDialog se cierra
                                if (detailsDialog.isReturnSuccessful()) {
                                    // Si la devolución fue exitosa, cerrar este diálogo de escaneo
                                    JOptionPane.showMessageDialog(this, "Herramienta devuelta y registrada exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                                    dispose(); // Esto llamará a stopWebcam() gracias al WindowListener/dispose override
                                } else {
                                    // Si no fue exitosa (cancelada, error), permitir reintentar el escaneo
                                    resultTextArea.setText("Devolución no completada. Intente escanear de nuevo.");
                                    isReading.set(true); // Reanudar el escaneo
                                }
                            } catch (NumberFormatException ex) {
                                JOptionPane.showMessageDialog(this, "El contenido del QR no es un ID de herramienta válido: " + qrContent, "Error de QR", JOptionPane.ERROR_MESSAGE);
                                resultTextArea.setText("Error: QR no válido. Escanee un QR de herramienta.");
                                isReading.set(true); // Reanudar escaneo
                            }
                        });

                    } catch (NotFoundException e) {
                        // No se encontró QR en este frame, continuar escaneando
                    } catch (Exception e) {
                        System.err.println("Error inesperado al procesar el frame: " + e.getMessage());
                        e.printStackTrace();
                        SwingUtilities.invokeLater(() -> resultTextArea.setText("Error al leer QR: " + e.getMessage()));
                        isReading.set(true); // Reanudar escaneo después de un error no fatal
                    }
                }
            }
        }, 0, 100, TimeUnit.MILLISECONDS);
        isReading.set(true); // Activar la lectura al inicio
    }

    private void stopWebcam() {
        isReading.set(false); // Detener el flag de lectura
        if (executorService != null && !executorService.isShutdown()) {
            executorService.shutdown(); // Iniciar el apagado del servicio
            try {
                if (!executorService.awaitTermination(500, TimeUnit.MILLISECONDS)) { // Esperar un poco
                    executorService.shutdownNow(); // Forzar el cierre si no termina a tiempo
                }
            } catch (InterruptedException e) {
                executorService.shutdownNow();
                Thread.currentThread().interrupt(); // Restaurar el estado de interrupción
            }
        }
        if (webcam != null && webcam.isOpen()) {
            webcam.close(); // Cerrar la cámara
        }
    }

    @Override
    public void dispose() {
        stopWebcam(); // Asegurarse de detener la cámara y el servicio al cerrar el diálogo
        super.dispose();
    }
}