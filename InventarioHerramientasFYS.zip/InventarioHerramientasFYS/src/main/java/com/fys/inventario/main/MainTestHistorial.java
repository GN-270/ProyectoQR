package com.fys.inventario.main;

import com.fys.inventario.dao.EmpleadoDAO;
import com.fys.inventario.dao.HerramientaDAO;
import com.fys.inventario.dao.HistorialMovimientoDAO;
import com.fys.inventario.model.Empleado;
import com.fys.inventario.model.Herramienta;
import com.fys.inventario.model.HistorialMovimiento;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;
import java.time.format.DateTimeFormatter;

public class MainTestHistorial {

    public static void main(String[] args) {
        HistorialMovimientoDAO historialDAO = new HistorialMovimientoDAO();
        EmpleadoDAO empleadoDAO = new EmpleadoDAO();
        HerramientaDAO herramientaDAO = new HerramientaDAO();
        Scanner scanner = new Scanner(System.in);

        System.out.println("--- PRUEBA DE HISTORIALMOVIMIENTODAO ---");

        // Asegúrate de que el empleado y la herramienta existan en tu DB
        // Obtener Empleado por ID (ahora int)
        System.out.print("Introduce el ID del Empleado para la prueba (ej: 1): ");
        int idEmpleadoTest = 0;
        try {
            idEmpleadoTest = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.err.println("ID de empleado inválido. Debe ser un número entero.");
            scanner.close();
            return;
        }

        System.out.print("Introduce el ID de la Herramienta para la prueba (ej: 1): ");
        int idHerramientaTest = 0;
        try {
            idHerramientaTest = Integer.parseInt(scanner.nextLine());
        } catch (NumberFormatException e) {
            System.err.println("ID de herramienta inválido. Debe ser un número entero.");
            scanner.close();
            return;
        }


        Empleado empleadoPrestamo = empleadoDAO.obtenerEmpleadoPorId(idEmpleadoTest);
        Herramienta herramientaPrestamo = herramientaDAO.obtenerHerramientaPorId(idHerramientaTest);

        if (empleadoPrestamo == null) {
            System.err.println("ERROR: Empleado con ID " + idEmpleadoTest + " no encontrado. Por favor, asegúrate de que exista para la prueba.");
            scanner.close();
            return;
        }
        if (herramientaPrestamo == null) {
            System.err.println("ERROR: Herramienta con ID " + idHerramientaTest + " no encontrada. Por favor, asegúrate de que exista para la prueba.");
            scanner.close();
            return;
        }

        System.out.println("\nEmpleado para prueba: " + empleadoPrestamo.getNombres() + " " + empleadoPrestamo.getApellidos() + " (ID: " + empleadoPrestamo.getIdEmpleado() + ")");
        System.out.println("Herramienta para prueba: " + herramientaPrestamo.getNombre() + " (ID: " + herramientaPrestamo.getIdHerramienta() + ")");


        System.out.println("\n--- Registrando un movimiento de PRESTACION ---");
        // El constructor de HistorialMovimiento es: new HistorialMovimiento(Integer idHerramienta, Integer idEmpleado, String tipoMovimiento, LocalDateTime fechaHora, String observaciones)
        HistorialMovimiento prestamo = new HistorialMovimiento(
                herramientaPrestamo.getIdHerramienta(), // idHerramienta (ya es Integer)
                empleadoPrestamo.getIdEmpleado(),       // idEmpleado (ya es int, se autoboxea a Integer)
                "Prestacion",                           // tipoMovimiento
                LocalDateTime.now(),                    // fechaHora (generada en el momento)
                "Herramienta prestada para trabajo en campo." // observaciones
        );

        if (historialDAO.agregarMovimiento(prestamo)) {
            System.out.println("Movimiento de prestación registrado exitosamente. ID: " + prestamo.getIdMovimiento());
        } else {
            System.out.println("Fallo al registrar el movimiento de prestación.");
        }

        System.out.println("\n--- Registrando un movimiento de DEVOLUCION ---");
        // El constructor de HistorialMovimiento es: new HistorialMovimiento(Integer idHerramienta, Integer idEmpleado, String tipoMovimiento, LocalDateTime fechaHora, String observaciones)
        HistorialMovimiento devolucion = new HistorialMovimiento(
                herramientaPrestamo.getIdHerramienta(), // idHerramienta (ya es Integer)
                empleadoPrestamo.getIdEmpleado(),       // idEmpleado (ya es int, se autoboxea a Integer)
                "Devolucion",                           // tipoMovimiento
                LocalDateTime.now(),                    // fechaHora (generada en el momento)
                "Herramienta devuelta después de uso, estado ok." // observaciones
        );

        if (historialDAO.agregarMovimiento(devolucion)) {
            System.out.println("Movimiento de devolución registrado exitosamente. ID: " + devolucion.getIdMovimiento());
        } else {
            System.out.println("Fallo al registrar el movimiento de devolución.");
        }


        System.out.println("\n--- Listado de todos los movimientos en el historial (más recientes primero) ---");
        List<HistorialMovimiento> todosLosMovimientos = historialDAO.obtenerTodosMovimientos();
        if (todosLosMovimientos.isEmpty()) {
            System.out.println("No hay movimientos registrados en el historial.");
        } else {
            listarMovimientos(todosLosMovimientos);
        }

        System.out.println("\n--- Movimientos del Empleado: " + empleadoPrestamo.getNombres() + " " + empleadoPrestamo.getApellidos() + " (ID: " + empleadoPrestamo.getIdEmpleado() + ") ---");
        // Usar buscarMovimientos para filtrar por ID de empleado
        // El método espera Integer, empleadoPrestamo.getIdEmpleado() es int y se autoboxea
        List<HistorialMovimiento> movimientosPorEmpleado = historialDAO.buscarMovimientos(empleadoPrestamo.getIdEmpleado(), null, null);
        if (movimientosPorEmpleado.isEmpty()) {
            System.out.println("No hay movimientos registrados para este empleado.");
        } else {
            listarMovimientos(movimientosPorEmpleado);
        }

        System.out.println("\n--- Movimientos de la Herramienta: " + herramientaPrestamo.getNombre() + " (ID: " + herramientaPrestamo.getIdHerramienta() + ") ---");
        // Usar buscarMovimientos para filtrar por ID de herramienta
        // El método espera Integer, herramientaPrestamo.getIdHerramienta() es int y se autoboxea
        List<HistorialMovimiento> movimientosPorHerramienta = historialDAO.buscarMovimientos(null, herramientaPrestamo.getIdHerramienta(), null);
        if (movimientosPorHerramienta.isEmpty()) {
            System.out.println("No hay movimientos registrados para esta herramienta.");
        } else {
            listarMovimientos(movimientosPorHerramienta);
        }

        System.out.println("\n--- Movimientos de tipo 'Prestacion' ---");
        List<HistorialMovimiento> movimientosPrestacion = historialDAO.buscarMovimientos(null, null, "Prestacion");
        if (movimientosPrestacion.isEmpty()) {
            System.out.println("No hay movimientos de tipo 'Prestacion'.");
        } else {
            listarMovimientos(movimientosPrestacion);
        }

        scanner.close();
        System.out.println("\n--- FIN DE LA PRUEBA DE HISTORIALMOVIMIENTODAO ---");
    }

    private static void listarMovimientos(List<HistorialMovimiento> movimientos) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        if (movimientos == null || movimientos.isEmpty()) {
            System.out.println("  No hay movimientos para listar.");
            return;
        }

        for (HistorialMovimiento mov : movimientos) {
            System.out.println(
                    "ID Mov: " + mov.getIdMovimiento() +
                            ", Tipo: " + mov.getTipoAccion() +
                            ", Fecha: " + mov.getFechaHora().format(formatter) +
                            ", Empleado: " + (mov.getNombreEmpleado() != null ? mov.getNombreEmpleado() : "N/A (ID: " + mov.getIdEmpleado() + ")") +
                            ", Herramienta: " + (mov.getNombreHerramienta() != null ? mov.getNombreHerramienta() : "N/A (ID: " + mov.getIdHerramienta() + ")") +
                            ", Observaciones: " + (mov.getComentarios() != null ? mov.getComentarios() : "N/A")
            );
        }
    }
}