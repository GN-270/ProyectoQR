package com.fys.inventario.dao;

import com.fys.inventario.model.Empleado;
import com.fys.inventario.util.DatabaseConnection;
import com.fys.inventario.util.QrCodeUtil;
import com.fys.inventario.util.QrCodeUtil.QrType;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.io.IOException;
import com.google.zxing.WriterException;

import javax.swing.*;

/**
 * Clase DAO (Data Access Object) para la entidad Empleado.
 * Provee métodos para interactuar con la tabla 'Empleados' en la base de datos.
 */
public class EmpleadoDAO {

    /**
     * Agrega un nuevo empleado a la base de datos.
     * El ID del empleado se generará automáticamente en la DB,
     * luego se genera y guarda el QR con ese ID.
     *
     * @param empleado El objeto Empleado a agregar.
     * @return true si el empleado fue agregado exitosamente, false en caso contrario.
     */
    public boolean agregarEmpleado(Empleado empleado) {
        // La columna qr_code_path se actualizará después de obtener el ID
        String sql = "INSERT INTO Empleados (dni, nombres, apellidos, labor, qr_code_path) VALUES (?, ?, ?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS); // Para obtener el ID autogenerado

            pstmt.setString(1, empleado.getDni());
            pstmt.setString(2, empleado.getNombres());
            pstmt.setString(3, empleado.getApellidos());
            pstmt.setString(4, empleado.getLabor());
            pstmt.setString(5, null); // qr_code_path inicialmente null

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                rs = pstmt.getGeneratedKeys();
                if (rs.next()) {
                    empleado.setIdEmpleado(rs.getInt(1)); // Establecer el ID auto-generado en el objeto

                    // --- GENERAR Y GUARDAR QR DESPUÉS DE OBTENER EL ID ---
                    String qrContent = String.valueOf(empleado.getIdEmpleado()); // Contenido del QR es el ID del empleado
                    String qrFileName = "qr_empleado_" + empleado.getIdEmpleado();
                    String qrPath = null;
                    try {
                        qrPath = QrCodeUtil.generateAndSaveQrCode(qrContent, qrFileName, QrType.EMPLEADO);
                    } catch (IOException | WriterException e) {
                        System.err.println("Error al generar o guardar el código QR para el empleado " + empleado.getIdEmpleado() + ": " + e.getMessage());
                        e.printStackTrace();
                        // Continúa sin QR path si hay un error en la generación
                    }

                    if (qrPath != null) {
                        // Actualizar el empleado en la DB con la ruta del QR
                        String updateSql = "UPDATE Empleados SET qr_code_path = ? WHERE id_empleado = ?";
                        try (PreparedStatement updatePstmt = conn.prepareStatement(updateSql)) {
                            updatePstmt.setString(1, qrPath);
                            updatePstmt.setInt(2, empleado.getIdEmpleado());
                            updatePstmt.executeUpdate();
                            empleado.setQrCodePath(qrPath); // Actualizar el objeto Empleado también
                        }
                    }
                    // --- FIN GENERACIÓN Y ACTUALIZACIÓN QR ---
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error al agregar empleado: " + e.getMessage());
            // Se puede verificar e.getSQLState() para errores de duplicidad (por ejemplo, para el DNI)
            if (e.getSQLState().startsWith("23")) { // SQLState para violación de restricción de integridad (duplicidad, etc.)
                JOptionPane.showMessageDialog(null, "Error: DNI duplicado o datos inválidos.", "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
            }
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return false;
    }

    /**
     * Obtiene una lista de todos los empleados.
     * @return Una lista de objetos Empleado.
     */
    public List<Empleado> obtenerTodosEmpleados() {
        List<Empleado> empleados = new ArrayList<>();
        String sql = "SELECT id_empleado, dni, nombres, apellidos, labor, qr_code_path FROM Empleados";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();

            while (rs.next()) {
                empleados.add(new Empleado(
                        rs.getInt("id_empleado"), // Leer como int
                        rs.getString("dni"),
                        rs.getString("nombres"),
                        rs.getString("apellidos"),
                        rs.getString("labor"),
                        rs.getString("qr_code_path")
                ));
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener todos los empleados: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return empleados;
    }

    /**
     * Obtiene un empleado por su ID.
     * @param idEmpleado El ID del empleado a buscar.
     * @return El objeto Empleado si se encuentra, o null si no existe.
     */
    public Empleado obtenerEmpleadoPorId(int idEmpleado) { // Recibe int
        String sql = "SELECT id_empleado, dni, nombres, apellidos, labor, qr_code_path FROM Empleados WHERE id_empleado = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        Empleado empleado = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, idEmpleado); // Establecer el parámetro como int
            rs = pstmt.executeQuery();

            if (rs.next()) {
                empleado = new Empleado(
                        rs.getInt("id_empleado"), // Leer como int
                        rs.getString("dni"),
                        rs.getString("nombres"),
                        rs.getString("apellidos"),
                        rs.getString("labor"),
                        rs.getString("qr_code_path")
                );
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener empleado por ID: " + e.getMessage());
            e.printStackTrace();
        } finally {
            if (rs != null) {
                try { rs.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
        return empleado;
    }

    /**
     * Actualiza la información de un empleado existente en la base de datos.
     * @param empleado El objeto Empleado con la información actualizada.
     * @return true si el empleado fue actualizado exitosamente, false en caso contrario.
     */
    public boolean actualizarEmpleado(Empleado empleado) {
        String sql = "UPDATE Empleados SET dni = ?, nombres = ?, apellidos = ?, labor = ?, qr_code_path = ? WHERE id_empleado = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);

            // --- Lógica de Re-Generación de QR para Empleado ---
            // Solo generar/re-generar si qrCodePath es null o vacío.
            if (empleado.getQrCodePath() == null || empleado.getQrCodePath().isEmpty() || empleado.getQrCodePath().equals("N/A")) { // Añadir "N/A" check
                String qrContent = String.valueOf(empleado.getIdEmpleado());
                String qrFileName = "qr_empleado_" + empleado.getIdEmpleado();
                String qrPath = null;
                try {
                    qrPath = QrCodeUtil.generateAndSaveQrCode(qrContent, qrFileName, QrType.EMPLEADO);
                } catch (IOException | WriterException e) {
                    System.err.println("Error al generar/re-generar el código QR para el empleado " + empleado.getIdEmpleado() + ": " + e.getMessage());
                    e.printStackTrace();
                    // No retornamos false aquí, permitimos la actualización del resto de campos.
                }
                if (qrPath != null) {
                    empleado.setQrCodePath(qrPath); // Actualizar el objeto con la nueva ruta QR
                }
            }


            pstmt.setString(1, empleado.getDni());
            pstmt.setString(2, empleado.getNombres());
            pstmt.setString(3, empleado.getApellidos());
            pstmt.setString(4, empleado.getLabor());
            pstmt.setString(5, empleado.getQrCodePath());
            pstmt.setInt(6, empleado.getIdEmpleado()); // Establecer el parámetro como int

            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al actualizar empleado: " + e.getMessage());
            if (e.getSQLState().startsWith("23")) { // SQLState para violación de restricción de integridad (duplicidad, etc.)
                JOptionPane.showMessageDialog(null, "Error: DNI duplicado o datos inválidos al actualizar.", "Error de Base de Datos", JOptionPane.ERROR_MESSAGE);
            }
            e.printStackTrace();
            return false;
        } finally {
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
    }

    /**
     * Elimina un empleado de la base de datos.
     * @param idEmpleado El ID del empleado a eliminar.
     * @return true si el empleado fue eliminado exitosamente, false en caso contrario.
     */
    public boolean eliminarEmpleado(int idEmpleado) { // Recibe int
        String sql = "DELETE FROM Empleados WHERE id_empleado = ?";
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, idEmpleado); // Establecer el parámetro como int

            int filasAfectadas = pstmt.executeUpdate();
            return filasAfectadas > 0;

        } catch (SQLException e) {
            System.err.println("Error al eliminar empleado: " + e.getMessage());
            // Puedes añadir lógica para detectar si el empleado tiene herramientas asignadas o historial
            if (e.getSQLState().startsWith("23")) { // Por ejemplo, integridad referencial (FOREIGN KEY constraint)
                JOptionPane.showMessageDialog(null, "No se puede eliminar el empleado porque está asociado a herramientas o movimientos en el historial.", "Error de Integridad", JOptionPane.ERROR_MESSAGE);
            }
            e.printStackTrace(); // Imprimir el stack trace para depuración
            return false;
        } finally {
            if (pstmt != null) {
                try { pstmt.close(); } catch (SQLException e) { e.printStackTrace(); }
            }
            DatabaseConnection.closeConnection(conn);
        }
    }
}