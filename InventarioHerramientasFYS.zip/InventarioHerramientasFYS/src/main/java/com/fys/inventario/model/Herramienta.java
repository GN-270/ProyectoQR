package com.fys.inventario.model;

public class Herramienta {
    private int idHerramienta;
    private String nombre;
    private String marca;
    private String descripcion;
    private String estado;
    private String disponibilidad;
    private Integer asignadoAIdEmpleado; // Correcto, Integer para permitir null
    private String asignadoANombreCompleto; // Correcto, para mostrar en UI
    private String qrCodePath; // Correcto


    public Herramienta(int idHerramienta, String nombre, String marca, String descripcion,
                       String estado, String disponibilidad, Integer asignadoAIdEmpleado, String qrCodePath) {
        this.idHerramienta = idHerramienta;
        this.nombre = nombre;
        this.marca = marca;
        this.descripcion = descripcion;
        this.estado = estado;
        this.disponibilidad = disponibilidad;
        this.asignadoAIdEmpleado = asignadoAIdEmpleado;
        this.qrCodePath = qrCodePath; // Ya lo inicializa
    }


    public Herramienta(String nombre, String marca, String descripcion,
                       String estado, String disponibilidad, Integer asignadoAIdEmpleado) {
        this.nombre = nombre;
        this.marca = marca;
        this.descripcion = descripcion;
        this.estado = estado;
        this.disponibilidad = disponibilidad;
        this.asignadoAIdEmpleado = asignadoAIdEmpleado;
        this.qrCodePath = null; // <--- MODIFICACIÓN AQUÍ: Inicializar qrCodePath a null
        //      Si este constructor se usa para crear nuevas herramientas antes de generar el QR
    }


    public Herramienta() {
        // Constructor vacío, útil para frameworks. Los campos se inicializarán a sus valores por defecto (0, null).
    }


    public int getIdHerramienta() {
        return idHerramienta;
    }

    public void setIdHerramienta(int idHerramienta) {
        this.idHerramienta = idHerramienta;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getDisponibilidad() {
        return disponibilidad;
    }

    public void setDisponibilidad(String disponibilidad) {
        this.disponibilidad = disponibilidad;
    }

    public Integer getAsignadoAIdEmpleado() { // Retorna Integer
        return asignadoAIdEmpleado;
    }

    public void setAsignadoAIdEmpleado(Integer asignadoAIdEmpleado) { // Recibe Integer
        this.asignadoAIdEmpleado = asignadoAIdEmpleado;
    }

    public String getAsignadoANombreCompleto() {
        return asignadoANombreCompleto;
    }

    public void setAsignadoANombreCompleto(String asignadoANombreCompleto) {
        this.asignadoANombreCompleto = asignadoANombreCompleto;
    }

    public String getQrCodePath() {
        return qrCodePath;
    }

    public void setQrCodePath(String qrCodePath) {
        this.qrCodePath = qrCodePath;
    }

    @Override
    public String toString() {
        return "Herramienta{" +
                "idHerramienta=" + idHerramienta +
                ", nombre='" + nombre + '\'' +
                ", marca='" + marca + '\'' +
                ", descripcion='" + descripcion + '\'' +
                ", estado='" + estado + '\'' +
                ", disponibilidad='" + disponibilidad + '\'' +
                ", asignadoAIdEmpleado=" + asignadoAIdEmpleado +
                ", asignadoANombreCompleto='" + (asignadoANombreCompleto != null ? asignadoANombreCompleto : "N/A") + '\'' + // Mejorar toString
                ", qrCodePath='" + (qrCodePath != null ? qrCodePath : "N/A") + '\'' + // Mejorar toString
                '}';
    }
}