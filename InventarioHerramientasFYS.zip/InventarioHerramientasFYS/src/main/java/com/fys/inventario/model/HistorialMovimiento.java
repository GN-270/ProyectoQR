package com.fys.inventario.model;

import java.time.LocalDateTime;

public class HistorialMovimiento {
    private int idMovimiento;
    private Integer idHerramienta;
    private String nombreHerramienta;
    private Integer idEmpleado;
    private String nombreEmpleado;
    private String tipoAccion; // Ya lo tienes como tipoAccion
    private LocalDateTime fechaHora;
    private String comentarios; // Ya lo tienes como comentarios

    // Constructor completo para recuperar de la DB
    public HistorialMovimiento(int idMovimiento, Integer idHerramienta, String nombreHerramienta,
                               Integer idEmpleado, String nombreEmpleado, String tipoAccion,
                               LocalDateTime fechaHora, String comentarios) {
        this.idMovimiento = idMovimiento;
        this.idHerramienta = idHerramienta;
        this.nombreHerramienta = nombreHerramienta;
        this.idEmpleado = idEmpleado;
        this.nombreEmpleado = nombreEmpleado;
        this.tipoAccion = tipoAccion;
        this.fechaHora = fechaHora;
        this.comentarios = comentarios;
    }

    // Constructor para un nuevo movimiento (ID se autogenera)
    public HistorialMovimiento(Integer idHerramienta, Integer idEmpleado, String tipoAccion,
                               LocalDateTime fechaHora, String comentarios) {
        this.idHerramienta = idHerramienta;
        this.idEmpleado = idEmpleado;
        this.tipoAccion = tipoAccion;
        this.fechaHora = fechaHora;
        this.comentarios = comentarios;
        // Los campos nombreHerramienta y nombreEmpleado no se inicializan aquí, lo cual es correcto
        // porque se obtendrán mediante JOINs o se establecerán más tarde si es necesario para la UI.
    }

    // Constructor vacío
    public HistorialMovimiento() {}

    // --- Getters y Setters ---

    public int getIdMovimiento() {
        return idMovimiento;
    }

    public void setIdMovimiento(int idMovimiento) {
        this.idMovimiento = idMovimiento;
    }

    public Integer getIdHerramienta() {
        return idHerramienta;
    }

    public void setIdHerramienta(Integer idHerramienta) {
        this.idHerramienta = idHerramienta;
    }

    public String getNombreHerramienta() {
        return nombreHerramienta;
    }

    public void setNombreHerramienta(String nombreHerramienta) {
        this.nombreHerramienta = nombreHerramienta;
    }

    public Integer getIdEmpleado() {
        return idEmpleado;
    }

    public void setIdEmpleado(Integer idEmpleado) {
        this.idEmpleado = idEmpleado;
    }

    public String getNombreEmpleado() {
        return nombreEmpleado;
    }

    public void setNombreEmpleado(String nombreEmpleado) {
        this.nombreEmpleado = nombreEmpleado;
    }

    public String getTipoAccion() {
        return tipoAccion;
    }

    public void setTipoAccion(String tipoAccion) {
        this.tipoAccion = tipoAccion;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getComentarios() {
        return comentarios;
    }

    public void setComentarios(String comentarios) {
        this.comentarios = comentarios;
    }

    @Override
    public String toString() {
        return "HistorialMovimiento{" +
                "idMovimiento=" + idMovimiento +
                ", idHerramienta=" + idHerramienta +
                ", nombreHerramienta='" + (nombreHerramienta != null ? nombreHerramienta : "N/A") + '\'' +
                ", idEmpleado=" + idEmpleado +
                ", nombreEmpleado='" + (nombreEmpleado != null ? nombreEmpleado : "N/A") + '\'' +
                ", tipoAccion='" + tipoAccion + '\'' +
                ", fechaHora=" + fechaHora +
                ", comentarios='" + (comentarios != null ? comentarios : "N/A") + '\'' +
                '}';
    }
}